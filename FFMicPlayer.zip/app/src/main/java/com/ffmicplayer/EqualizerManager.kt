package com.ffmicplayer

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import android.util.Log

class EqualizerManager(audioSessionId: Int) {

    private const val TAG = "EqualizerManager"

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var reverb: PresetReverb? = null

    var isEnabled = false
        private set

    init {
        try {
            equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
            bassBoost = BassBoost(0, audioSessionId).apply { enabled = true }
            virtualizer = Virtualizer(0, audioSessionId).apply { enabled = true }
            reverb = PresetReverb(0, audioSessionId).apply { enabled = true }
            isEnabled = true
            Log.d(TAG, "Effects initialized. EQ bands: ${equalizer?.numberOfBands}")
        } catch (e: Exception) {
            Log.e(TAG, "Effects init error: ${e.message}")
        }
    }

    // Returns list of band center frequencies in Hz
    fun getBandFrequencies(): List<Int> {
        val eq = equalizer ?: return emptyList()
        return (0 until eq.numberOfBands).map {
            eq.getCenterFreq(it.toShort()) / 1000 // mHz -> Hz
        }
    }

    // Returns current band levels in millibels
    fun getBandLevels(): List<Int> {
        val eq = equalizer ?: return emptyList()
        return (0 until eq.numberOfBands).map {
            eq.getBandLevel(it.toShort()).toInt()
        }
    }

    fun getLevelRange(): Pair<Int, Int> {
        val eq = equalizer ?: return Pair(-1500, 1500)
        return Pair(
            eq.bandLevelRange[0].toInt(),
            eq.bandLevelRange[1].toInt()
        )
    }

    fun setBandLevel(band: Int, level: Int) {
        try {
            equalizer?.setBandLevel(band.toShort(), level.toShort())
        } catch (e: Exception) {
            Log.e(TAG, "SetBandLevel error: ${e.message}")
        }
    }

    // strength: 0-1000
    fun setBassBoost(strength: Int) {
        try {
            bassBoost?.setStrength(strength.toShort())
        } catch (e: Exception) {
            Log.e(TAG, "BassBoost error: ${e.message}")
        }
    }

    fun getBassBoostStrength(): Int = bassBoost?.roundedStrength?.toInt() ?: 0

    // strength: 0-1000
    fun setVirtualizer(strength: Int) {
        try {
            virtualizer?.setStrength(strength.toShort())
        } catch (e: Exception) {
            Log.e(TAG, "Virtualizer error: ${e.message}")
        }
    }

    fun getVirtualizerStrength(): Int = virtualizer?.roundedStrength?.toInt() ?: 0

    // preset: PresetReverb.PRESET_*
    fun setReverb(preset: Short) {
        try {
            reverb?.preset = preset
        } catch (e: Exception) {
            Log.e(TAG, "Reverb error: ${e.message}")
        }
    }

    fun applyPreset(preset: EqPreset) {
        val eq = equalizer ?: return
        preset.bandLevels.forEachIndexed { index, level ->
            if (index < eq.numberOfBands) {
                eq.setBandLevel(index.toShort(), level.toShort())
            }
        }
        setBassBoost(preset.bassBoost)
        setVirtualizer(preset.virtualizer)
    }

    fun release() {
        try {
            equalizer?.release()
            bassBoost?.release()
            virtualizer?.release()
            reverb?.release()
        } catch (e: Exception) {
            Log.e(TAG, "Release error: ${e.message}")
        }
    }

    enum class EqPreset(
        val displayName: String,
        // millibels per band (60Hz, 230Hz, 910Hz, 3.6kHz, 14kHz)
        val bandLevels: List<Short>,
        val bassBoost: Int,
        val virtualizer: Int
    ) {
        NORMAL("Normal",
            listOf(0, 0, 0, 0, 0), 0, 0),
        BASS_BOOST("Bass Boost",
            listOf(600, 400, 0, 0, 0), 800, 200),
        TREBLE("Treble Boost",
            listOf(0, 0, 0, 400, 600), 0, 300),
        VOCAL("Vocal",
            listOf(-200, 0, 400, 400, 200), 100, 400),
        GAMING("Gaming (FF)",
            listOf(300, 200, 0, 300, 400), 400, 600),
        ROCK("Rock",
            listOf(400, 200, -100, 200, 400), 500, 300),
        FLAT("Flat",
            listOf(0, 0, 0, 0, 0), 0, 0)
    }
}
