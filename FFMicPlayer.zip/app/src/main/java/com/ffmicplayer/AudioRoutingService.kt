package com.ffmicplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat

class AudioRoutingService : Service() {

    private val TAG = "AudioRoutingService"
    private val CHANNEL_ID = "ff_mic_player_channel"
    private val NOTIFICATION_ID = 1001

    inner class LocalBinder : Binder() {
        fun getService() = this@AudioRoutingService
    }

    private val binder = LocalBinder()
    private var isRouting = false

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("FF Mic Player running"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_ROUTING -> startRouting()
            ACTION_STOP_ROUTING -> stopRouting()
        }
        return START_STICKY
    }

    fun startRouting(): Boolean {
        Log.d(TAG, "Starting virtual mic routing")
        return try {
            val supported = RootAudioRouter.isLoopbackSupported()
            Log.d(TAG, "Loopback supported: $supported")

            val enabled = RootAudioRouter.enableVirtualMic()
            Log.d(TAG, "Virtual mic enabled: $enabled")

            if (enabled) {
                RootAudioRouter.setLoopbackAsMic()
                isRouting = true
                updateNotification("🎵 Routing active — FF mic ON")
            }
            enabled
        } catch (e: Exception) {
            Log.e(TAG, "Routing error: ${e.message}")
            false
        }
    }

    fun stopRouting() {
        Log.d(TAG, "Stopping virtual mic routing")
        RootAudioRouter.disableVirtualMic()
        isRouting = false
        updateNotification("FF Mic Player — routing stopped")
    }

    fun isRouting() = isRouting

    private fun buildNotification(text: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FF Mic Player")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "FF Mic Player",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Audio routing for Free Fire mic"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        stopRouting()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START_ROUTING = "com.ffmicplayer.START_ROUTING"
        const val ACTION_STOP_ROUTING = "com.ffmicplayer.STOP_ROUTING"
    }
}
