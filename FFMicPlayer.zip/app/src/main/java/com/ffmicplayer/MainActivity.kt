package com.ffmicplayer

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.media.audiofx.PresetReverb
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.switchmaterial.SwitchMaterial
import com.topjohnwu.superuser.Shell

class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivity"

    // UI
    private lateinit var tvRootStatus: TextView
    private lateinit var tvNowPlaying: TextView
    private lateinit var switchRouting: SwitchMaterial
    private lateinit var btnPlay: ImageButton
    private lateinit var btnPrev: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var seekBarProgress: SeekBar
    private lateinit var seekBarVolume: SeekBar
    private lateinit var seekBarBass: SeekBar
    private lateinit var seekBarVirtualizer: SeekBar
    private lateinit var spinnerEqPreset: Spinner
    private lateinit var spinnerReverb: Spinner
    private lateinit var rvSongs: RecyclerView
    private lateinit var tvCurrentTime: TextView
    private lateinit var tvTotalTime: TextView
    private lateinit var tvRoutingStatus: TextView
    private lateinit var layoutEqBands: LinearLayout

    // Core
    private lateinit var musicPlayer: MusicPlayer
    private var equalizerManager: EqualizerManager? = null
    private var routingService: AudioRoutingService? = null
    private var serviceBound = false

    private lateinit var songAdapter: SongAdapter
    private var currentSongIndex = 0
    private val handler = Handler(Looper.getMainLooper())

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val localBinder = binder as AudioRoutingService.LocalBinder
            routingService = localBinder.getService()
            serviceBound = true
            Log.d(TAG, "Service connected")
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            serviceBound = false
            routingService = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Init root shell first
        Shell.enableVerboseLogging = BuildConfig.DEBUG
        Shell.setDefaultBuilder(
            Shell.Builder.create()
                .setFlags(Shell.FLAG_REDIRECT_STDERR)
                .setTimeout(10)
        )

        initViews()
        checkPermissions()
        bindRoutingService()
        setupMusicPlayer()
    }

    private fun initViews() {
        tvRootStatus      = findViewById(R.id.tvRootStatus)
        tvNowPlaying      = findViewById(R.id.tvNowPlaying)
        switchRouting     = findViewById(R.id.switchRouting)
        btnPlay           = findViewById(R.id.btnPlay)
        btnPrev           = findViewById(R.id.btnPrev)
        btnNext           = findViewById(R.id.btnNext)
        seekBarProgress   = findViewById(R.id.seekBarProgress)
        seekBarVolume     = findViewById(R.id.seekBarVolume)
        seekBarBass       = findViewById(R.id.seekBarBass)
        seekBarVirtualizer= findViewById(R.id.seekBarVirtualizer)
        spinnerEqPreset   = findViewById(R.id.spinnerEqPreset)
        spinnerReverb     = findViewById(R.id.spinnerReverb)
        rvSongs           = findViewById(R.id.rvSongs)
        tvCurrentTime     = findViewById(R.id.tvCurrentTime)
        tvTotalTime       = findViewById(R.id.tvTotalTime)
        tvRoutingStatus   = findViewById(R.id.tvRoutingStatus)
        layoutEqBands     = findViewById(R.id.layoutEqBands)

        // RecyclerView
        songAdapter = SongAdapter(emptyList()) { song, index ->
            playSong(song, index)
        }
        rvSongs.layoutManager = LinearLayoutManager(this)
        rvSongs.adapter = songAdapter

        // Play/Pause
        btnPlay.setOnClickListener {
            if (musicPlayer.isPlaying()) {
                musicPlayer.pause()
                btnPlay.setImageResource(android.R.drawable.ic_media_play)
            } else {
                musicPlayer.play()
                btnPlay.setImageResource(android.R.drawable.ic_media_pause)
                startProgressUpdate()
            }
        }

        btnPrev.setOnClickListener { playPrevious() }
        btnNext.setOnClickListener { playNext() }

        // Seek
        seekBarProgress.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) musicPlayer.seekTo(progress)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // Volume
        seekBarVolume.max = 100
        seekBarVolume.progress = 80
        seekBarVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                val vol = progress / 100f
                musicPlayer.setVolume(vol, vol)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // Bass
        seekBarBass.max = 1000
        seekBarBass.progress = 0
        seekBarBass.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                equalizerManager?.setBassBoost(progress)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // Virtualizer
        seekBarVirtualizer.max = 1000
        seekBarVirtualizer.progress = 0
        seekBarVirtualizer.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                equalizerManager?.setVirtualizer(progress)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // EQ Presets spinner
        val presets = EqualizerManager.EqPreset.values().map { it.displayName }
        spinnerEqPreset.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, presets)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        spinnerEqPreset.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                val preset = EqualizerManager.EqPreset.values()[pos]
                equalizerManager?.applyPreset(preset)
                seekBarBass.progress = preset.bassBoost
                seekBarVirtualizer.progress = preset.virtualizer
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        // Reverb spinner
        val reverbOptions = listOf("None", "Small Room", "Medium Room", "Large Room", "Medium Hall", "Large Hall", "Plate")
        spinnerReverb.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, reverbOptions)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        spinnerReverb.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                val preset = when (pos) {
                    0 -> PresetReverb.PRESET_NONE
                    1 -> PresetReverb.PRESET_SMALLROOM
                    2 -> PresetReverb.PRESET_MEDIUMROOM
                    3 -> PresetReverb.PRESET_LARGEROOM
                    4 -> PresetReverb.PRESET_MEDIUMHALL
                    5 -> PresetReverb.PRESET_LARGEHALL
                    6 -> PresetReverb.PRESET_PLATE
                    else -> PresetReverb.PRESET_NONE
                }
                equalizerManager?.setReverb(preset)
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        // Routing switch
        switchRouting.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                val success = routingService?.startRouting() ?: false
                if (success) {
                    tvRoutingStatus.text = "🟢 Virtual Mic: ON — teammates sunte parbe"
                    tvRoutingStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light))
                } else {
                    tvRoutingStatus.text = "🔴 Routing failed — root check koro"
                    tvRoutingStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_light))
                    switchRouting.isChecked = false
                }
            } else {
                routingService?.stopRouting()
                tvRoutingStatus.text = "⚫ Virtual Mic: OFF"
                tvRoutingStatus.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray))
            }
        }
    }

    private fun setupMusicPlayer() {
        musicPlayer = MusicPlayer(this)
        musicPlayer.onCompletionListener = { playNext() }
        musicPlayer.onErrorListener = { err ->
            runOnUiThread {
                Toast.makeText(this, "Error: $err", Toast.LENGTH_SHORT).show()
            }
        }
        musicPlayer.setVolume(0.8f, 0.8f)
    }

    private fun playSong(song: Song, index: Int) {
        currentSongIndex = index
        musicPlayer.load(song.path)
        musicPlayer.play()
        btnPlay.setImageResource(android.R.drawable.ic_media_pause)
        tvNowPlaying.text = "${song.title} — ${song.artist}"
        seekBarProgress.max = musicPlayer.getDuration()
        songAdapter.setCurrentPlaying(index)
        startProgressUpdate()

        // Init equalizer on new session
        val sessionId = musicPlayer.getAudioSessionId()
        equalizerManager?.release()
        equalizerManager = EqualizerManager(sessionId)
        buildEqBandSliders()
    }

    private fun buildEqBandSliders() {
        layoutEqBands.removeAllViews()
        val eq = equalizerManager ?: return
        val freqs = eq.getBandFrequencies()
        val levels = eq.getBandLevels()
        val range = eq.getLevelRange()

        freqs.forEachIndexed { i, freq ->
            val label = TextView(this).apply {
                text = "${freq}Hz"
                setTextColor(ContextCompat.getColor(context, android.R.color.white))
                textAlignment = View.TEXT_ALIGNMENT_CENTER
            }
            val sb = SeekBar(this).apply {
                max = range.second - range.first
                progress = levels.getOrElse(i) { 0 } - range.first
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                        if (fromUser) eq.setBandLevel(i, p + range.first)
                    }
                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) {}
                })
            }
            layoutEqBands.addView(label)
            layoutEqBands.addView(sb)
        }
    }

    private fun playNext() {
        val songs = songAdapter.getSongs()
        if (songs.isEmpty()) return
        currentSongIndex = (currentSongIndex + 1) % songs.size
        playSong(songs[currentSongIndex], currentSongIndex)
    }

    private fun playPrevious() {
        val songs = songAdapter.getSongs()
        if (songs.isEmpty()) return
        currentSongIndex = if (currentSongIndex > 0) currentSongIndex - 1 else songs.size - 1
        playSong(songs[currentSongIndex], currentSongIndex)
    }

    private fun startProgressUpdate() {
        handler.removeCallbacksAndMessages(null)
        handler.post(object : Runnable {
            override fun run() {
                if (musicPlayer.isPlaying()) {
                    val pos = musicPlayer.getCurrentPosition()
                    val dur = musicPlayer.getDuration()
                    seekBarProgress.max = dur
                    seekBarProgress.progress = pos
                    tvCurrentTime.text = formatMs(pos)
                    tvTotalTime.text = formatMs(dur)
                }
                handler.postDelayed(this, 500)
            }
        })
    }

    private fun loadSongsFromDevice() {
        val songs = mutableListOf<Song>()
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        contentResolver.query(uri, projection, selection, null, sortOrder)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol) ?: "Unknown"
                val artist = cursor.getString(artistCol) ?: "Unknown"
                val path = cursor.getString(dataCol) ?: continue
                val duration = cursor.getLong(durCol)
                songs.add(Song(title, artist, path, duration))
            }
        }

        runOnUiThread {
            songAdapter.updateSongs(songs)
            if (songs.isEmpty()) {
                Toast.makeText(this, "Kono song paoa jায়ni storage-e", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "${songs.size}ta song loaded", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun checkRootAndUpdateUI() {
        Shell.cmd("id").submit { result ->
            runOnUiThread {
                if (result.isSuccess && result.out.any { it.contains("uid=0") }) {
                    tvRootStatus.text = "✅ Root: Connected"
                    tvRootStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light))
                } else {
                    tvRootStatus.text = "❌ Root: Not found"
                    tvRootStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_light))
                    Toast.makeText(this, "Root access nai! App kaj korbe na.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun bindRoutingService() {
        val intent = Intent(this, AudioRoutingService::class.java)
        startService(intent)
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun checkPermissions() {
        val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.RECORD_AUDIO
            )
        } else {
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.RECORD_AUDIO
            )
        }
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        } else {
            onPermissionsGranted()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            onPermissionsGranted()
        } else {
            Toast.makeText(this, "Permission dite hobe app chalate", Toast.LENGTH_LONG).show()
        }
    }

    private fun onPermissionsGranted() {
        checkRootAndUpdateUI()
        Thread { loadSongsFromDevice() }.start()
    }

    private fun formatMs(ms: Int): String {
        val totalSec = ms / 1000
        val min = totalSec / 60
        val sec = totalSec % 60
        return "%d:%02d".format(min, sec)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        musicPlayer.release()
        equalizerManager?.release()
        if (serviceBound) {
            unbindService(serviceConnection)
            serviceBound = false
        }
        super.onDestroy()
    }
}
