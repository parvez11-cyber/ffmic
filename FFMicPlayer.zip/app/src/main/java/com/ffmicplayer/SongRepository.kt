package com.ffmicplayer

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Song-er 3 ta source:
 *  1. Device-er music (MediaStore)
 *  2. User-er pick kora file (file picker / SAF)
 *  3. Online link theke download kora file (app-er private folder-e save hoy)
 *
 * Sob function background thread-e call korte hobe.
 */
object SongRepository {

    private const val TAG = "SongRepository"
    private const val PREFS = "ffmic_prefs"
    private const val KEY_PICKED = "picked_uris"

    private val AUDIO_EXT = setOf(
        "mp3", "m4a", "aac", "ogg", "oga", "opus", "wav", "flac", "amr", "mp4", "3gp", "mid"
    )

    // ---------------- Device songs ----------------

    fun loadDeviceSongs(context: Context): List<Song> {
        val songs = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        try {
            context.contentResolver.query(collection, projection, selection, null, sortOrder)
                ?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                    val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                    val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        // content:// uri — Android 10+ (scoped storage) e file path er bodole eta lage
                        val uri = ContentUris.withAppendedId(collection, id)
                        songs.add(
                            Song(
                                title = cursor.getString(titleCol) ?: "Unknown",
                                artist = cursor.getString(artistCol) ?: "Unknown",
                                path = uri.toString(),
                                duration = cursor.getLong(durCol)
                            )
                        )
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Device songs load error: ${e.message}")
        }
        return songs
    }

    // ---------------- Picked + downloaded ----------------

    /** App start-e: age pick kora + download kora sob song. */
    fun loadAdded(context: Context): List<Song> {
        val result = mutableListOf<Song>()

        for (uriStr in getPickedUris(context)) {
            val uri = Uri.parse(uriStr)
            if (!canOpen(context, uri)) continue // permission/file nai
            result.add(buildSong(context, uri))
        }

        downloadsDir(context).listFiles()
            ?.filter { it.isFile && it.extension.lowercase(Locale.ROOT) in AUDIO_EXT }
            ?.sortedByDescending { it.lastModified() }
            ?.forEach { result.add(buildSong(context, Uri.fromFile(it))) }

        return result
    }

    /** File picker theke ashha uri save kore Song banay. */
    fun addPicked(context: Context, uri: Uri): Song? {
        try {
            context.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (e: Exception) {
            // kichu provider persistable dey na — tokhon ei session-e kaj korbe
            Log.w(TAG, "Persist permission failed: ${e.message}")
        }
        if (!canOpen(context, uri)) return null

        val list = getPickedUris(context).toMutableList()
        if (!list.contains(uri.toString())) {
            list.add(uri.toString())
            savePickedUris(context, list)
        }
        return buildSong(context, uri)
    }

    private fun getPickedUris(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_PICKED, "") ?: ""
        return raw.split("\n").filter { it.isNotBlank() }
    }

    private fun savePickedUris(context: Context, list: List<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_PICKED, list.joinToString("\n")).apply()
    }

    private fun canOpen(context: Context, uri: Uri): Boolean = try {
        context.contentResolver.openInputStream(uri)?.use { true } ?: false
    } catch (e: Exception) {
        false
    }

    private fun buildSong(context: Context, uri: Uri): Song {
        var displayName: String? = null
        if (uri.scheme == "content") {
            try {
                context.contentResolver.query(
                    uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
                )?.use { c ->
                    if (c.moveToFirst()) displayName = c.getString(0)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Display name query failed: ${e.message}")
            }
        }
        val fileName = displayName ?: uri.lastPathSegment ?: "Audio"
        var title = fileName.substringBeforeLast('.')
        var artist = "Unknown"
        var duration = 0L

        val mmr = MediaMetadataRetriever()
        try {
            mmr.setDataSource(context, uri)
            mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                ?.takeIf { it.isNotBlank() }?.let { title = it }
            mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                ?.takeIf { it.isNotBlank() }?.let { artist = it }
            duration = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            Log.w(TAG, "Metadata read failed: ${e.message}")
        } finally {
            try { mmr.release() } catch (e: Exception) { /* ignore */ }
        }
        return Song(title, artist, uri.toString(), duration)
    }

    // ---------------- Online download ----------------

    fun downloadsDir(context: Context): File {
        val dir = File(context.filesDir, "downloads")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /**
     * Direct audio link (mp3/m4a/ogg/wav...) theke file download kore.
     * onProgress(percent, bytes): percent -1 mane size jana nai.
     */
    fun download(
        context: Context,
        urlStr: String,
        onProgress: (Int, Long) -> Unit
    ): Song {
        val startUrl = try {
            URL(urlStr.trim())
        } catch (e: Exception) {
            throw IOException("Link ta valid na")
        }
        if (startUrl.protocol != "http" && startUrl.protocol != "https") {
            throw IOException("Shudhu http/https link cholbe")
        }

        val (conn, finalUrl) = openFollowingRedirects(startUrl)
        var target: File? = null
        var success = false
        try {
            val type = conn.contentType?.lowercase(Locale.ROOT) ?: ""
            if (type.startsWith("text/") || type.contains("html")) {
                throw IOException("Eta webpage, direct audio file-er link na (.mp3 / .m4a ... link dao)")
            }

            val fileName = buildFileName(conn, finalUrl, type)
            val file = uniqueFile(downloadsDir(context), fileName)
            target = file

            val total = conn.contentLengthLong
            var downloaded = 0L
            var lastPct = -2
            conn.inputStream.use { input ->
                file.outputStream().use { output ->
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        downloaded += n
                        val pct = if (total > 0) ((downloaded * 100) / total).toInt() else -1
                        if (pct != lastPct) {
                            lastPct = pct
                            onProgress(pct, downloaded)
                        }
                    }
                }
            }

            val song = buildSong(context, Uri.fromFile(file))
            if (song.duration <= 0L) {
                throw IOException("File ta valid audio na")
            }
            success = true
            return song
        } finally {
            conn.disconnect()
            if (!success) {
                try { target?.delete() } catch (e: Exception) { /* ignore */ }
            }
        }
    }

    private fun openFollowingRedirects(start: URL): Pair<HttpURLConnection, URL> {
        var current = start
        var redirects = 0
        while (true) {
            val conn = current.openConnection() as HttpURLConnection
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.instanceFollowRedirects = false
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) FFMicPlayer")
            val code = conn.responseCode
            if (code in 300..399) {
                val loc = conn.getHeaderField("Location")
                conn.disconnect()
                if (loc.isNullOrBlank()) throw IOException("Bad redirect")
                if (++redirects > 5) throw IOException("Onek beshi redirect")
                current = URL(current, loc) // http -> https o handle hoy
                continue
            }
            if (code !in 200..299) {
                conn.disconnect()
                throw IOException("Server error $code")
            }
            return Pair(conn, current)
        }
    }

    private fun buildFileName(conn: HttpURLConnection, url: URL, type: String): String {
        val fromHeader = conn.getHeaderField("Content-Disposition")?.let {
            Regex("filename\\*?=(?:UTF-8'')?\"?([^\";]+)\"?", RegexOption.IGNORE_CASE)
                .find(it)?.groupValues?.get(1)
        }
        var name = fromHeader ?: url.path.substringAfterLast('/')
        name = try { Uri.decode(name) } catch (e: Exception) { name }
        name = name.replace(Regex("[^A-Za-z0-9._ -]"), "_").trim().ifBlank { "audio" }

        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (ext !in AUDIO_EXT) {
            name = name.trimEnd('.') + "." + extFromType(type)
        }
        return name.take(100)
    }

    private fun extFromType(type: String): String = when {
        type.contains("mpeg") || type.contains("mp3") -> "mp3"
        type.contains("mp4") || type.contains("m4a") || type.contains("aac") -> "m4a"
        type.contains("ogg") -> "ogg"
        type.contains("opus") -> "opus"
        type.contains("wav") -> "wav"
        type.contains("flac") -> "flac"
        else -> "mp3"
    }

    private fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val base = name.substringBeforeLast('.')
        val ext = name.substringAfterLast('.', "")
        var i = 1
        while (f.exists()) {
            f = File(dir, "$base($i).$ext")
            i++
        }
        return f
    }
}
