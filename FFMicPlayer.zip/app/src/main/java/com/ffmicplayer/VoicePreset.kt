package com.ffmicplayer

import android.media.audiofx.PresetReverb

/**
 * Voice changer presets. Player-er audio (jeta virtual mic-e jacche) er
 * pitch + EQ + reverb change kore.
 */
enum class VoicePreset(
    val label: String,
    val pitch: Float,
    val eq: EqualizerManager.EqPreset,
    val reverb: Short
) {
    NORMAL("Normal", 1.00f, EqualizerManager.EqPreset.NORMAL, PresetReverb.PRESET_NONE),
    DEEP("Deep", 0.78f, EqualizerManager.EqPreset.BASS_BOOST, PresetReverb.PRESET_NONE),
    HIGH("High", 1.30f, EqualizerManager.EqPreset.VOCAL, PresetReverb.PRESET_NONE),
    CHIPMUNK("Chipmunk", 1.65f, EqualizerManager.EqPreset.TREBLE, PresetReverb.PRESET_NONE),
    ECHO("Echo", 1.00f, EqualizerManager.EqPreset.NORMAL, PresetReverb.PRESET_LARGEHALL)
}
