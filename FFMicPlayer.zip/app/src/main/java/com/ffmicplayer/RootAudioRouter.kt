package com.ffmicplayer

import android.util.Log
import com.topjohnwu.superuser.Shell

object RootAudioRouter {

    private const val TAG = "RootAudioRouter"
    private var isRoutingActive = false

    // Check if device supports pcm loopback
    fun isLoopbackSupported(): Boolean {
        val result = Shell.cmd("ls /dev/snd/").exec()
        val output = result.out.joinToString(" ")
        Log.d(TAG, "SND devices: $output")
        return result.isSuccess
    }

    // Load pcm loopback kernel module and create virtual mic
    fun enableVirtualMic(): Boolean {
        if (isRoutingActive) return true

        // Step 1: Try loading snd-aloop kernel module
        val modLoad = Shell.cmd(
            "modprobe snd-aloop || insmod /system/lib/modules/snd-aloop.ko 2>/dev/null || true"
        ).exec()
        Log.d(TAG, "Module load: ${modLoad.out}")

        // Step 2: Check loopback device created
        val checkLoop = Shell.cmd("ls /dev/snd/ | grep -i loop").exec()
        val hasLoop = checkLoop.out.isNotEmpty()
        Log.d(TAG, "Loopback device exists: $hasLoop")

        // Step 3: Use tinymix / amixer to route loopback playback -> capture
        // This routes virtual playback device output to virtual capture (mic) input
        val routeResult = Shell.cmd(
            // Try amixer first (most devices)
            "amixer -c 1 sset 'Loopback Mixer' on 2>/dev/null || " +
            // Fallback: tinymix (needs tinymix binary in PATH or /system/bin)
            "tinymix -D 1 set 'Loopback Mixer' 1 2>/dev/null || " +
            "echo 'route_attempted'"
        ).exec()
        Log.d(TAG, "Route result: ${routeResult.out}")

        // Step 4: Set loopback device as default capture source
        val setDefault = Shell.cmd(
            // Try setting via AudioPolicyManager prop
            "setprop ro.audio.monitorOrientation false 2>/dev/null;" +
            // Force mic source to loopback card (card 1 typically after snd-aloop)
            "amixer -c 1 sset 'PCM' 100% 2>/dev/null || true"
        ).exec()
        Log.d(TAG, "Set default: ${setDefault.out}")

        isRoutingActive = routeResult.isSuccess || hasLoop
        return isRoutingActive
    }

    // Start piping audio from playback to mic using tee + aplay/arecord trick
    fun startAudioPipe(): Boolean {
        // arecord from default (music output) and pipe to aplay on loopback capture
        // This keeps the pipe alive in background
        val pipe = Shell.cmd(
            "arecord -D hw:0,0 -f cd -t raw 2>/dev/null | " +
            "aplay -D hw:1,1 -f cd 2>/dev/null &"
        ).exec()
        Log.d(TAG, "Pipe started: ${pipe.isSuccess}, out: ${pipe.out}")
        return pipe.isSuccess
    }

    // Redirect mic input: route snd-aloop capture as default mic
    fun setLoopbackAsMic(): Boolean {
        // Android reads mic from AudioRecord with MIC source.
        // We override the audio policy to point MIC source -> loopback capture device
        val result = Shell.cmd(
            // Write audio_policy_configuration override if writable
            "mount -o remount,rw /system 2>/dev/null;" +
            // Set loopback as primary capture device via AudioFlinger prop
            "setprop af.resampler.quality 4;" +
            // Some kernels: use virtual_mic overlay
            "ls /proc/asound/card1 2>/dev/null && echo 'loopback_card_found' || echo 'not_found'"
        ).exec()
        Log.d(TAG, "Set loopback as mic: ${result.out}")
        return result.out.any { it.contains("loopback_card_found") }
    }

    fun disableVirtualMic(): Boolean {
        isRoutingActive = false
        val result = Shell.cmd(
            // Kill any background arecord/aplay pipes
            "pkill -f 'arecord' 2>/dev/null;" +
            "pkill -f 'aplay' 2>/dev/null;" +
            // Unload loopback module
            "rmmod snd_aloop 2>/dev/null || true"
        ).exec()
        Log.d(TAG, "Disabled virtual mic: ${result.out}")
        return result.isSuccess
    }

    fun isRoutingActive() = isRoutingActive

    fun getRootStatus(): String {
        val result = Shell.cmd("id").exec()
        return result.out.firstOrNull() ?: "unknown"
    }

    fun checkRootAccess(): Boolean {
        return Shell.getShell().isRoot
    }
}
