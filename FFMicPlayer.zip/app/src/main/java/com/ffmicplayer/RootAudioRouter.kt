package com.ffmicplayer

import android.util.Log
import com.topjohnwu.superuser.Shell

object RootAudioRouter {

    private const val TAG = "RootAudioRouter"
    private var isRoutingActive = false

    // Check if device supports pcm loopback
    fun isLoopbackSupported(): Boolean {
        val result = Shell.cmd("ls /dev/snd/").exec()
        val output = result.out.joinToString(" ")
        Log.d(TAG, "SND devices: $output")
        return result.isSuccess
    }

    // mt6768 AFE: playback (DL1/DL12) ke capture UL4-er sathe mix kora (mic + music)
    private val routeControls = listOf(
        "UL4_CH1 DL1_CH1", "UL4_CH2 DL1_CH2",
        "UL4_CH1 DL12_CH1", "UL4_CH2 DL12_CH2",
        // UL2 capture-o ekshathe (je-i game-er mic pore, ekta-te music thakbe)
        "UL2_CH1 DL1_CH1", "UL2_CH2 DL1_CH2",
        "UL2_CH1 DL12_CH1", "UL2_CH2 DL12_CH2",
        "UL2_CH1 DL2_CH1", "UL2_CH2 DL2_CH2",
        "UL2_CH1 DL3_CH1", "UL2_CH2 DL3_CH2"
    )

    private fun setControl(name: String, on: Boolean) {
        val v = if (on) "1" else "0"
        Shell.cmd("tinymix set '$name' $v 2>/dev/null || tinymix '$name' $v 2>/dev/null").exec()
    }

    private fun controlIsOn(name: String): Boolean {
        val out = Shell.cmd("tinymix 2>/dev/null | grep -F '$name'").exec().out
        return out.any { it.trim().endsWith("On") && it.contains(name) }
    }

    // Playback -> capture AFE route on kori, tinymix diye verify kori
    fun enableVirtualMic(): Boolean {
        if (isRoutingActive) return true
        routeControls.forEach { setControl(it, true) }
        val ok = routeControls.any { controlIsOn(it) }
        Log.d(TAG, "AFE route verified: $ok")
        isRoutingActive = ok
        return ok
    }

    // Start piping audio from playback to mic using tee + aplay/arecord trick
    fun startAudioPipe(): Boolean {
        // arecord from default (music output) and pipe to aplay on loopback capture
        // This keeps the pipe alive in background
        val pipe = Shell.cmd(
            "arecord -D hw:0,0 -f cd -t raw 2>/dev/null | " +
            "aplay -D hw:1,1 -f cd 2>/dev/null &"
        ).exec()
        Log.d(TAG, "Pipe started: ${pipe.isSuccess}, out: ${pipe.out}")
        return pipe.isSuccess
    }

    // Loopback card ache kina check kore (system partition-e kono poriborton kore na)
    fun setLoopbackAsMic(): Boolean {
        val result = Shell.cmd(
            "grep -i loop /proc/asound/cards >/dev/null 2>&1 && echo loopback_card_found || echo not_found"
        ).exec()
        Log.d(TAG, "Loopback card check: ${result.out}")
        return result.out.any { it.contains("loopback_card_found") }
    }

    fun disableVirtualMic(): Boolean {
        isRoutingActive = false
        routeControls.forEach { setControl(it, false) }
        return true
    }

    fun isRoutingActive() = isRoutingActive

    fun getRootStatus(): String {
        val result = Shell.cmd("id").exec()
        return result.out.firstOrNull() ?: "unknown"
    }

    fun checkRootAccess(): Boolean {
        return Shell.getShell().isRoot
    }

    // Read-only check: phone-e routing-er jonno ki ki ache
    fun diagnose(): String {
        val script = """
            echo "== root =="; id
            echo "== device =="
            getprop ro.product.model; getprop ro.product.manufacturer
            getprop ro.board.platform; getprop ro.build.version.release
            uname -r
            echo "== sound cards =="; cat /proc/asound/cards 2>&1
            echo "== /dev/snd =="; ls /dev/snd 2>&1
            echo "== loaded modules =="; (lsmod 2>&1 | grep -i -E "aloop|snd" ) || echo "none/lsmod nai"
            echo "== kernel config =="; (zcat /proc/config.gz 2>/dev/null | grep -i -E "SND_ALOOP|SND_DUMMY") || echo "config.gz nai"
            echo "== aloop module file =="; (find /vendor/lib/modules /system/lib/modules /lib/modules -iname "*aloop*" 2>/dev/null | head -3) || true
            echo "== tools =="; for t in tinymix amixer tinycap tinyplay aplay arecord; do which ${'$'}t || echo "${'$'}t: nai"; done
            echo "== audio policy =="; ls /vendor/etc/audio_policy_configuration.xml /system/etc/audio_policy_configuration.xml 2>&1
            echo "== hardware =="; getprop ro.hardware; getprop ro.hardware.audio.primary; getprop ro.vendor.mediatek.platform
            echo "== pcm devices =="; cat /proc/asound/pcm 2>&1 | head -40
            echo "== audio files =="; ls /vendor/etc /vendor/etc/audio /system/etc 2>/dev/null | grep -i -E "audio|mixer" | head -20
            echo "== policy: submix/input =="; (dumpsys media.audio_policy 2>&1 | grep -i -E "submix|input device|available input" | head -25) || true
            echo "== mixer controls (UL/DL/loop) =="; (tinymix 2>&1 | grep -i -E "loop|ADDA|UL1|UL2|DL1|I2S|AFE|Mux" | head -50) || echo "tinymix nai"
        """.trimIndent()
        val result = Shell.cmd(script).exec()
        return result.out.joinToString("\n")
    }

    // Game-er mic kon capture PCM khule dekhe: duration ms dhore poll kore
    fun probeCapture(durationMs: Long): String {
        val seen = linkedMapOf<String, String>()
        val end = System.currentTimeMillis() + durationMs
        while (System.currentTimeMillis() < end) {
            val out = Shell.cmd(
                "for f in /proc/asound/card0/pcm*c/sub0/status; do " +
                    "echo \"\$f \$(head -1 \$f)\"; done"
            ).exec().out
            out.filter { it.contains("RUNNING") || it.contains("PREPARED") || it.contains("state: ") && !it.contains("closed") }
                .forEach { line ->
                    val key = line.substringBefore(' ')
                    seen[key] = line
                }
            try { Thread.sleep(500) } catch (e: InterruptedException) { break }
        }
        val routes = routeControls.joinToString("\n") { "$it = ${if (controlIsOn(it)) "On" else "Off"}" }
        return "== capture PCM active (probe) ==\n" +
            (if (seen.isEmpty()) "kono capture PCM open paoa jayni" else seen.values.joinToString("\n")) +
            "\n== route state ==\n" + routes
    }

    // Puro mixer list + audio policy file Download folder-e rakhe (paste-er jonno boro)
    fun dumpFull(): String {
        val dir = "/sdcard/Download"
        val r = Shell.cmd(
            "mkdir -p $dir; tinymix > $dir/ffmic_mixer.txt 2>&1; " +
                "cp /vendor/etc/audio_policy_configuration.xml $dir/ffmic_policy.txt 2>&1; " +
                "cat /proc/asound/card0/pcm*c/sub0/status > $dir/ffmic_capture_status.txt 2>&1; " +
                "ls -la $dir/ffmic_*"
        ).exec()
        return r.out.joinToString("\n")
    }
}
