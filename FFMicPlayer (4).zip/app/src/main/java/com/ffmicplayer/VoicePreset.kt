package com.ffmicplayer

import android.media.audiofx.PresetReverb

/**
 * Voice changer presets. Player-er audio (jeta virtual mic-e jacche) er
 * pitch + EQ + reverb change kore. Pitch beshi charle "chen chen" noise hoy,
 * tai ekhane shob pitch narom rakha hoyeche.
 */
enum class VoicePreset(
    val label: String,
    val pitch: Float,
    val eq: EqualizerManager.EqPreset,
    val reverb: Short
) {
    NORMAL("Normal", 1.00f, EqualizerManager.EqPreset.NORMAL, PresetReverb.PRESET_NONE),
    DEEP("Deep", 0.86f, EqualizerManager.EqPreset.SOFT_BASS, PresetReverb.PRESET_NONE),
    HIGH("High", 1.18f, EqualizerManager.EqPreset.CLEAN_VOICE, PresetReverb.PRESET_NONE),
    CHIPMUNK("Chipmunk", 1.40f, EqualizerManager.EqPreset.CLEAN_VOICE, PresetReverb.PRESET_NONE),
    ECHO("Echo", 1.00f, EqualizerManager.EqPreset.NORMAL, PresetReverb.PRESET_LARGEHALL),
    GIANT("👹 Giant", 0.78f, EqualizerManager.EqPreset.SOFT_BASS, PresetReverb.PRESET_SMALLROOM),
    MONSTER("🧟 Monster", 0.80f, EqualizerManager.EqPreset.SOFT_BASS, PresetReverb.PRESET_NONE),
    GIRL("👧 Girl", 1.28f, EqualizerManager.EqPreset.CLEAN_VOICE, PresetReverb.PRESET_NONE),
    CUTE_GIRL("💖 Cute Girl", 1.34f, EqualizerManager.EqPreset.CLEAN_VOICE, PresetReverb.PRESET_NONE),
    BABY("👶 Baby", 1.48f, EqualizerManager.EqPreset.CLEAN_VOICE, PresetReverb.PRESET_NONE),
    ALIEN("👽 Alien", 1.55f, EqualizerManager.EqPreset.CLEAN_VOICE, PresetReverb.PRESET_NONE),
    CAVE("🕳 Cave", 0.92f, EqualizerManager.EqPreset.NORMAL, PresetReverb.PRESET_LARGEHALL),
    STADIUM("🏟 Stadium", 1.00f, EqualizerManager.EqPreset.CLEAR, PresetReverb.PRESET_LARGEHALL),
    ROBOT("🤖 Robot", 0.90f, EqualizerManager.EqPreset.RADIO, PresetReverb.PRESET_SMALLROOM),
    RADIO("📻 Radio", 1.00f, EqualizerManager.EqPreset.RADIO, PresetReverb.PRESET_NONE),
    DEMON("😈 Demon", 0.72f, EqualizerManager.EqPreset.SOFT_BASS, PresetReverb.PRESET_NONE),
    TUNG_TUNG("🪵 Tung Tung", 0.80f, EqualizerManager.EqPreset.SOFT_BASS, PresetReverb.PRESET_NONE),
    FUNNY("🤪 Funny", 1.40f, EqualizerManager.EqPreset.CLEAN_VOICE, PresetReverb.PRESET_NONE)
}
