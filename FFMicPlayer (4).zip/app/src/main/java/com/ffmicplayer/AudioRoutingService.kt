package com.ffmicplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

class AudioRoutingService : Service() {

    private val TAG = "AudioRoutingService"
    private val CHANNEL_ID = "ff_mic_player_channel"
    private val NOTIFICATION_ID = 1001

    inner class LocalBinder : Binder() {
        fun getService() = this@AudioRoutingService
    }

    private val binder = LocalBinder()
    private var isRouting = false

    // Root nai hole true: gaan speaker diye bajbe, game-er mic sheta pick korbe
    @Volatile
    var speakerMode = false
        private set
    private var floating: FloatingController? = null

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        instance = this
        PlayerHub.init(this)
        floating = FloatingController(this)
        createNotificationChannel()

        // Android 14/15: foreground service type dewa lage
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        } else {
            0
        }
        ServiceCompat.startForeground(
            this, NOTIFICATION_ID, buildNotification("FF Mic Player running"), type
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_ROUTING -> PlayerHub.setRouting(true)
            ACTION_STOP_ROUTING -> PlayerHub.setRouting(false)
            ACTION_SHOW_FLOATING -> showFloating()
            ACTION_HIDE_FLOATING -> floating?.hide()
            ACTION_QUIT -> {
                quit()
                return START_NOT_STICKY
            }
            else -> {
                // system service restart korle (intent == null) floating abar dekhao
                val wanted = getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getBoolean(KEY_FLOATING, false)
                if (wanted) showFloating()
            }
        }
        return START_STICKY
    }

    private fun showFloating() {
        if (canDrawOverlays(this)) {
            floating?.show()
        } else {
            Log.w(TAG, "Overlay permission nai")
        }
    }

    private fun quit() {
        floating?.hide()
        PlayerHub.shutdown()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    fun startRouting(): Boolean {
        Log.d(TAG, "Starting virtual mic routing")
        val useRoot = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("use_root", true)
        val hasRoot = useRoot && try {
            RootAudioRouter.checkRootAccess()
        } catch (e: Exception) {
            false
        }
        if (!hasRoot) {
            speakerMode = true
            isRouting = true
            updateNotification("🔊 Speaker mode ON — mic speaker-er awaj pick korbe")
            return true
        }
        speakerMode = false
        return try {
            val supported = RootAudioRouter.isLoopbackSupported()
            Log.d(TAG, "Loopback supported: $supported")

            val enabled = RootAudioRouter.enableVirtualMic()
            Log.d(TAG, "Virtual mic enabled: $enabled")

            if (enabled) {
                RootAudioRouter.setLoopbackAsMic()
                isRouting = true
                updateNotification("🎵 Routing active — FF mic ON")
                true
            } else {
                // Root ache kintu ei phone-e loopback nai: Speaker Mode e cholo
                speakerMode = true
                isRouting = true
                updateNotification("🔊 Speaker mode ON — loopback nai, mic speaker theke nibe")
                true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Routing error: ${e.message}")
            false
        }
    }

    fun stopRouting() {
        Log.d(TAG, "Stopping virtual mic routing")
        if (!speakerMode) RootAudioRouter.disableVirtualMic()
        speakerMode = false
        isRouting = false
        updateNotification("FF Mic Player — routing stopped")
    }

    // Speaker mode-e media volume kom thakle game-er mic gaan tulte parbe na, tai 85%-e tulbo
    fun boostMediaVolume() {
        try {
            val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
            val max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
            val want = (max * 0.85f).toInt()
            if (am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) < want) {
                am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, want, 0)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Volume boost error: ${e.message}")
        }
    }

    fun isRouting() = isRouting

    private fun buildNotification(text: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val quitIntent = Intent(this, AudioRoutingService::class.java).setAction(ACTION_QUIT)
        val quitPi = PendingIntent.getService(
            this, 1, quitIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FF Mic Player")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pi)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Quit", quitPi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "FF Mic Player",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Audio routing for Free Fire mic"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        floating?.hide()
        floating = null
        if (isRouting) stopRouting()
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_START_ROUTING = "com.ffmicplayer.START_ROUTING"
        const val ACTION_STOP_ROUTING = "com.ffmicplayer.STOP_ROUTING"
        const val ACTION_SHOW_FLOATING = "com.ffmicplayer.SHOW_FLOATING"
        const val ACTION_HIDE_FLOATING = "com.ffmicplayer.HIDE_FLOATING"
        const val ACTION_QUIT = "com.ffmicplayer.QUIT"

        const val PREFS = "ffmic_prefs"
        const val KEY_FLOATING = "floating_enabled"

        @Volatile
        var instance: AudioRoutingService? = null
            private set

        fun canDrawOverlays(context: Context): Boolean =
            Settings.canDrawOverlays(context)
    }
}
