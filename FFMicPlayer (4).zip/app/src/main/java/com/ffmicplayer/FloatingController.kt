package com.ffmicplayer

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.animation.Animator
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.os.Handler
import android.os.Looper
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.HorizontalScrollView
import android.widget.SeekBar
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/**
 * Screen-er upore (Free Fire-er upore-o) bhasha choto mic icon.
 * Drag kora jay. Tap korle panel khole: Mic ON/OFF, Voice change, play/pause.
 */
class FloatingController(private val context: Context) : PlayerHub.Listener {

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var expanded = false

    private var bubble: TextView? = null
    private var panel: View? = null
    private var toggle: TextView? = null
    private var play: TextView? = null
    private var now: TextView? = null
    private var voiceRow: LinearLayout? = null
    private val chips = mutableListOf<TextView>()

    private var seek: SeekBar? = null
    private var ring1: View? = null
    private var ring2: View? = null
    private val ringAnims = mutableListOf<Animator>()
    private var ringsOn = false
    private val ui = Handler(Looper.getMainLooper())
    private val progressTick = object : Runnable {
        override fun run() {
            if (root == null) return
            if (expanded) {
                val s = seek
                if (s != null) {
                    val dur = PlayerHub.duration()
                    if (s.max != dur && dur > 0) s.max = dur
                    if (!seeking) s.progress = PlayerHub.position()
                }
            }
            ui.postDelayed(this, 500)
        }
    }
    private var seeking = false

    private val density = context.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    fun isShowing() = root != null

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (root != null) return

        val view = LayoutInflater.from(context).inflate(R.layout.overlay_floating, null)
        bubble = view.findViewById(R.id.fcBubble)
        panel = view.findViewById(R.id.fcPanel)
        toggle = view.findViewById(R.id.fcToggle)
        play = view.findViewById(R.id.fcPlay)
        now = view.findViewById(R.id.fcNow)
        voiceRow = view.findViewById(R.id.fcVoiceRow)
        seek = view.findViewById(R.id.fcSeek)
        ring1 = view.findViewById(R.id.fcRing1)
        ring2 = view.findViewById(R.id.fcRing2)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = dp(200)
        }
        params = lp

        buildVoiceChips()

        // Tap = panel khola/bondho, drag = soranu
        bubble?.setOnTouchListener(DragListener())

        toggle?.setOnClickListener {
            if (!PlayerHub.routingBusy) PlayerHub.setRouting(!PlayerHub.routingOn)
        }
        view.findViewById<View>(R.id.fcClose).setOnClickListener { setExpanded(false) }
        view.findViewById<View>(R.id.fcPrev).setOnClickListener { PlayerHub.previous() }
        view.findViewById<View>(R.id.fcNext).setOnClickListener { PlayerHub.next() }
        play?.setOnClickListener { PlayerHub.togglePlayPause() }

        try {
            wm.addView(view, lp)
        } catch (e: Exception) {
            // overlay permission nai ba window add hoyni
            Toast.makeText(context, "Floating icon dekhano gelo na: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }
        root = view
        PlayerHub.addListener(this)
        setupExtras(view)
        syncAll()
        // Dekha dewar somoy pop kore ase
        view.scaleX = 0f
        view.scaleY = 0f
        view.pivotX = 0f
        view.pivotY = 0f
        view.animate().scaleX(1f).scaleY(1f).setDuration(380)
            .setInterpolator(OvershootInterpolator(1.8f)).start()
        ui.post(progressTick)
    }

    fun hide() {
        PlayerHub.removeListener(this)
        ui.removeCallbacksAndMessages(null)
        ringAnims.forEach { it.cancel() }
        ringAnims.clear()
        ringsOn = false
        root?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
                // already removed
            }
        }
        root = null
        params = null
        expanded = false
        chips.clear()
    }

    // ---------- UI ----------

    private fun pop(v: View) {
        v.animate().cancel()
        v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(70).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(160)
                .setInterpolator(OvershootInterpolator(3f)).start()
        }.start()
    }

    private fun chipBg(v: TextView, active: Boolean) {
        v.background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(if (active) Color.parseColor("#0B6B7A") else Color.parseColor("#2A313B"))
            setStroke(dp(1), if (active) Color.parseColor("#00E5FF") else Color.parseColor("#3A4A5C"))
        }
    }

    private fun setupExtras(view: View) {
        // progress seekbar
        seek?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(sb: SeekBar) { seeking = true }
            override fun onStopTrackingTouch(sb: SeekBar) {
                seeking = false
                PlayerHub.seekTo(sb.progress)
            }
        })
        // volume
        val vol = view.findViewById<SeekBar>(R.id.fcVolume)
        vol.progress = (PlayerHub.volume * 100).toInt()
        vol.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) PlayerHub.setVolume(p / 100f)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        // shuffle / repeat
        val sh = view.findViewById<TextView>(R.id.fcShuffle)
        val rp = view.findViewById<TextView>(R.id.fcRepeat)
        fun syncModes() {
            sh.text = if (PlayerHub.shuffle) "🔀 On" else "🔀 Off"
            chipBg(sh, PlayerHub.shuffle)
            rp.text = when (PlayerHub.repeatMode) { 0 -> "🔁 Off"; 2 -> "🔂 One"; else -> "🔁 All" }
            chipBg(rp, PlayerHub.repeatMode != 0)
        }
        sh.setOnClickListener { pop(it); PlayerHub.shuffle = !PlayerHub.shuffle; syncModes() }
        rp.setOnClickListener { pop(it); PlayerHub.repeatMode = (PlayerHub.repeatMode + 1) % 3; syncModes() }
        syncModes()
        // soundboard
        val row = view.findViewById<LinearLayout>(R.id.fcSoundRow)
        SoundBoard.effects.forEach { fx ->
            val b = TextView(context).apply {
                text = fx.label
                textSize = 12f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(8), dp(10), dp(8))
                chipBg(this, false)
                setOnClickListener {
                    pop(it)
                    SoundBoard.play(fx, PlayerHub.volume, context, PlayerHub.routingSpeaker)
                }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(6) }
            row.addView(b, lp)
        }
    }

    // Mic ON thakle bubble-er chardike dheu
    private fun setRings(on: Boolean) {
        if (on == ringsOn) return
        ringsOn = on
        ringAnims.forEach { it.cancel() }
        ringAnims.clear()
        val rings = listOfNotNull(ring1, ring2)
        if (!on) {
            rings.forEach { it.alpha = 0f; it.scaleX = 1f; it.scaleY = 1f }
            return
        }
        rings.forEachIndexed { i, v ->
            val sx = ObjectAnimator.ofFloat(v, View.SCALE_X, 1f, 1.45f)
            val sy = ObjectAnimator.ofFloat(v, View.SCALE_Y, 1f, 1.45f)
            val a = ObjectAnimator.ofFloat(v, View.ALPHA, 0.8f, 0f)
            val set = AnimatorSet()
            listOf(sx, sy, a).forEach {
                it.repeatCount = ValueAnimator.INFINITE
                it.duration = 1500
                it.startDelay = 750L * i
                it.interpolator = LinearInterpolator()
            }
            set.playTogether(sx, sy, a)
            set.start()
            ringAnims.add(set)
        }
    }

    private fun buildVoiceChips() {
        val row = voiceRow ?: return
        row.removeAllViews()
        chips.clear()
        VoicePreset.values().forEach { preset ->
            val chip = TextView(context).apply {
                text = preset.label
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(6), dp(10), dp(6))
                setOnClickListener { PlayerHub.setVoice(preset) }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(6) }
            row.addView(chip, lp)
            chips.add(chip)
        }
    }

    private fun pill(color: Int, radiusDp: Int = 16): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(color)
        }

    private fun syncAll() {
        syncVoice()
        syncRouting()
        syncPlayState()
        syncTrack()
    }

    private fun syncVoice() {
        val presets = VoicePreset.values()
        chips.forEachIndexed { i, chip ->
            val selected = presets[i] == PlayerHub.voice
            chip.background = pill(if (selected) Color.parseColor("#00E5FF") else Color.parseColor("#2A313B"))
            chip.setTextColor(if (selected) Color.BLACK else Color.WHITE)
        }
    }

    private fun syncRouting() {
        val busy = PlayerHub.routingBusy
        val on = if (busy) PlayerHub.routingTarget else PlayerHub.routingOn
        toggle?.apply {
            text = if (busy) "..." else if (on) "ON" else "OFF"
            background = pill(
                if (busy) Color.parseColor("#B8860B")
                else if (on) Color.parseColor("#1E9E4A")
                else Color.parseColor("#555F6B")
            )
        }
        // bubble-er rong-o bole dey mic ON/OFF
        bubble?.let { b ->
            b.animate().cancel()
            if (on && !busy) {
                b.animate().scaleX(1.18f).scaleY(1.18f).setDuration(600).withEndAction { pulseBack(b) }.start()
            } else { b.scaleX = 1f; b.scaleY = 1f }
        }
        setRings(on && !busy)
        (bubble?.background as? GradientDrawable)?.setColor(
            if (on) Color.parseColor("#1E9E4A") else Color.parseColor("#555F6B")
        )
    }

    private fun pulseBack(b: View) {
        if (root == null || !PlayerHub.routingOn) { b.scaleX = 1f; b.scaleY = 1f; return }
        b.animate().scaleX(1f).scaleY(1f).setDuration(600).withEndAction {
            if (root != null && PlayerHub.routingOn) {
                b.animate().scaleX(1.18f).scaleY(1.18f).setDuration(600).withEndAction { pulseBack(b) }.start()
            }
        }.start()
    }

    private fun syncPlayState() {
        play?.text = if (PlayerHub.isPlaying()) "⏸" else "▶"
    }

    private fun syncTrack() {
        val s = PlayerHub.currentSong()
        now?.text = s?.title ?: "Kono song select kora hoyni"
    }

    private fun setExpanded(value: Boolean) {
        expanded = value
        val p = panel
        if (p != null) {
            p.animate().cancel()
            if (value) {
                p.visibility = View.VISIBLE
                p.alpha = 0f
                p.pivotX = 0f
                p.pivotY = 0f
                p.scaleX = 0.8f
                p.scaleY = 0.6f
                p.translationY = -dp(12).toFloat()
                p.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                    .setDuration(260).setInterpolator(OvershootInterpolator(1.4f)).start()
                bubble?.animate()?.rotationBy(360f)?.setDuration(420)?.start()
            } else {
                p.animate().alpha(0f).scaleX(0.9f).scaleY(0.8f).setDuration(160)
                    .withEndAction { p.visibility = View.GONE }.start()
            }
        }
        // panel khulle screen-er baire jeno na jay
        root?.postDelayed({ clampToScreen() }, 300)
    }

    private fun clampToScreen() {
        val lp = params ?: return
        val r = root ?: return
        val dm = context.resources.displayMetrics
        val maxX = (dm.widthPixels - r.width).coerceAtLeast(0)
        val maxY = (dm.heightPixels - r.height).coerceAtLeast(0)
        lp.x = lp.x.coerceIn(0, maxX)
        lp.y = lp.y.coerceIn(0, maxY)
        try { wm.updateViewLayout(r, lp) } catch (e: Exception) { /* ignore */ }
    }

    private fun snapToEdge() {
        val lp = params ?: return
        val r = root ?: return
        val dm = context.resources.displayMetrics
        val center = lp.x + r.width / 2
        lp.x = if (center < dm.widthPixels / 2) 0 else (dm.widthPixels - r.width).coerceAtLeast(0)
        lp.y = lp.y.coerceIn(0, (dm.heightPixels - r.height).coerceAtLeast(0))
        try { wm.updateViewLayout(r, lp) } catch (e: Exception) { /* ignore */ }
    }

    // ---------- Hub events ----------

    override fun onTrackChanged() = syncTrack()
    override fun onPlayStateChanged() = syncPlayState()
    override fun onVoiceChanged() = syncVoice()
    override fun onRoutingChanged() = syncRouting()
    override fun onMessage(msg: String) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    }

    // ---------- Drag ----------

    private inner class DragListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        private var moved = false

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val lp = params ?: return false
            val r = root ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - touchX
                    val dy = event.rawY - touchY
                    if (!moved && (abs(dx) > dp(6) || abs(dy) > dp(6))) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        try { wm.updateViewLayout(r, lp) } catch (e: Exception) { /* ignore */ }
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        setExpanded(!expanded)
                    } else if (!expanded) {
                        snapToEdge()
                    } else {
                        clampToScreen()
                    }
                    return true
                }
            }
            return false
        }
    }
}
