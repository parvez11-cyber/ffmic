package com.ffmicplayer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class Song(
    val title: String,
    val artist: String,
    val path: String,
    val duration: Long // ms
)

class SongAdapter(
    private var songs: List<Song>,
    private val onSongClick: (Song, Int) -> Unit
) : RecyclerView.Adapter<SongAdapter.SongViewHolder>() {

    private var currentPlayingIndex = -1
    private var lastAnimated = -1

    inner class SongViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.tvSongTitle)
        val artist: TextView = itemView.findViewById(R.id.tvSongArtist)
        val duration: TextView = itemView.findViewById(R.id.tvSongDuration)
        val playingIndicator: ImageView = itemView.findViewById(R.id.ivPlayingIndicator)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_song, parent, false)
        return SongViewHolder(view)
    }

    override fun onBindViewHolder(holder: SongViewHolder, position: Int) {
        val song = songs[position]
        holder.title.text = song.title
        holder.artist.text = song.artist
        holder.duration.text = formatDuration(song.duration)

        // Highlight currently playing song
        if (position == currentPlayingIndex) {
            holder.playingIndicator.visibility = View.VISIBLE
            holder.itemView.alpha = 1f
        } else {
            holder.playingIndicator.visibility = View.GONE
            holder.itemView.alpha = 0.75f
        }

        holder.itemView.setOnClickListener {
            it.animate().scaleX(0.97f).scaleY(0.97f).setDuration(70).withEndAction {
                it.animate().scaleX(1f).scaleY(1f).setDuration(110).start()
            }.start()
            onSongClick(song, position)
        }

        // Notun item niche theke ek ek kore bhese ase
        if (position > lastAnimated) {
            lastAnimated = position
            val target = if (position == currentPlayingIndex) 1f else 0.75f
            holder.itemView.alpha = 0f
            holder.itemView.translationX = 60f
            holder.itemView.animate().alpha(target).translationX(0f)
                .setStartDelay((position.coerceAtMost(8) * 40).toLong()).setDuration(300).start()
        } else {
            holder.itemView.translationX = 0f
        }
    }

    override fun getItemCount() = songs.size

    fun updateSongs(newSongs: List<Song>) {
        songs = newSongs
        lastAnimated = -1
        notifyDataSetChanged()
    }

    fun setCurrentPlaying(index: Int) {
        val old = currentPlayingIndex
        currentPlayingIndex = index
        if (old >= 0) notifyItemChanged(old)
        if (index >= 0) notifyItemChanged(index)
    }

    fun getSongs() = songs

    private fun formatDuration(ms: Long): String {
        val totalSec = ms / 1000
        val min = totalSec / 60
        val sec = totalSec % 60
        return "%d:%02d".format(min, sec)
    }
}
