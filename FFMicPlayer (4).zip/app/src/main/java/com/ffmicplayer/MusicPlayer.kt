package com.ffmicplayer

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.util.Log

class MusicPlayer(private val context: Context) {

    companion object {
        private const val TAG = "MusicPlayer"
    }

    private var mediaPlayer: MediaPlayer? = null
    private var currentPath: String? = null
    private var isPrepared = false
    private var pitch = 1.0f
    private var speed = 1.0f
    private var forceSpeaker = false

    // No-Root mode: music-ke phone-er loudspeaker-e pathao (headphone lagano thakleo, Android 9+)
    fun setForceSpeaker(on: Boolean) {
        forceSpeaker = on
        applyRoute()
    }

    private fun applyRoute() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val dev = if (forceSpeaker) {
                am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                    .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
            } else null
            mediaPlayer?.setPreferredDevice(dev)
        } catch (e: Exception) {
            Log.e(TAG, "Route error: ${e.message}")
        }
    }

    var onCompletionListener: (() -> Unit)? = null
    var onErrorListener: ((String) -> Unit)? = null

    fun load(path: String): Boolean {
        return try {
            release()
            currentPath = path
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        // Route through STREAM_MUSIC so loopback captures it
                        .setLegacyStreamType(AudioManager.STREAM_MUSIC)
                        .build()
                )
                setDataSource(context, Uri.parse(path))
                setOnPreparedListener {
                    isPrepared = true
                    Log.d(TAG, "Prepared: $path")
                }
                setOnCompletionListener {
                    onCompletionListener?.invoke()
                }
                setOnErrorListener { _, what, extra ->
                    onErrorListener?.invoke("MediaPlayer error: what=$what extra=$extra")
                    false
                }
                prepare()
                // prepare() sync, tai ekhoni ready (listener pore ashe, tar age play() hote pare)
                isPrepared = true
            }
            applyRoute()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Load error: ${e.message}")
            onErrorListener?.invoke(e.message ?: "Unknown error")
            false
        }
    }

    // Voice changer: pitch 0.5 - 2.0 (speed same thake)
    fun setPitch(value: Float) {
        pitch = value.coerceIn(0.5f, 2.0f)
        if (isPrepared && isPlaying()) applyPitch()
    }

    fun setSpeed(value: Float) {
        speed = value.coerceIn(0.5f, 1.5f)
        if (isPrepared && isPlaying()) applyPitch()
    }

    private fun applyPitch() {
        try {
            mediaPlayer?.playbackParams = PlaybackParams().setPitch(pitch).setSpeed(speed)
        } catch (e: Exception) {
            Log.e(TAG, "Pitch error: ${e.message}")
        }
    }

    fun play() {
        try {
            mediaPlayer?.let {
                if (isPrepared) {
                    it.start()
                    applyPitch()
                    Log.d(TAG, "Playing")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Play error: ${e.message}")
        }
    }

    fun pause() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) it.pause()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Pause error: ${e.message}")
        }
    }

    fun stop() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) it.stop()
                isPrepared = false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Stop error: ${e.message}")
        }
    }

    fun seekTo(ms: Int) {
        try {
            mediaPlayer?.seekTo(ms)
        } catch (e: Exception) {
            Log.e(TAG, "Seek error: ${e.message}")
        }
    }

    fun setVolume(left: Float, right: Float) {
        try {
            mediaPlayer?.setVolume(left, right)
        } catch (e: Exception) {
            Log.e(TAG, "Volume error: ${e.message}")
        }
    }

    fun isPlaying(): Boolean = mediaPlayer?.isPlaying ?: false

    fun getCurrentPosition(): Int = mediaPlayer?.currentPosition ?: 0

    fun getDuration(): Int = mediaPlayer?.duration ?: 0

    fun getAudioSessionId(): Int = mediaPlayer?.audioSessionId ?: 0

    fun release() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) it.stop()
                it.release()
            }
            mediaPlayer = null
            isPrepared = false
        } catch (e: Exception) {
            Log.e(TAG, "Release error: ${e.message}")
        }
    }

    fun getCurrentPath() = currentPath
}
