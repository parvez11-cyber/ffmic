package com.ffmicplayer

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/** Kono file chhara nijer toiri chhoto sound effect (airhorn, siren...). */
object SoundBoard {

    private const val SR = 44100

    data class Fx(val label: String, val gen: () -> ShortArray)

    private fun pcm(seconds: Float, f: (t: Float, i: Int) -> Float): ShortArray {
        val n = (seconds * SR).toInt()
        return ShortArray(n) { i ->
            val v = f(i / SR.toFloat(), i).coerceIn(-1f, 1f)
            (v * 30000).toInt().toShort()
        }
    }

    private fun tone(freq: Float, t: Float) = sin(2 * PI * freq * t).toFloat()
    private fun saw(freq: Float, t: Float): Float {
        val x = (freq * t) % 1f
        return 2f * x - 1f
    }
    private fun square(freq: Float, t: Float) = if (tone(freq, t) >= 0) 1f else -1f

    val effects: List<Fx> = listOf(
        Fx("📯 Airhorn") {
            pcm(1.0f) { t, _ ->
                val vib = 1f + 0.01f * tone(6f, t)
                val env = if (t < 0.03f) t / 0.03f else if (t > 0.85f) (1f - t) / 0.15f else 1f
                env * 0.3f * (saw(466f * vib, t) + saw(587f * vib, t) + saw(698f * vib, t))
            }
        },
        Fx("🚨 Siren") {
            pcm(2.2f) { t, _ ->
                val f = 900f + 300f * tone(1.2f, t)
                val phase = 900f * t - (300f / (2 * PI.toFloat() * 1.2f)) * (kotlin.math.cos(2 * PI * 1.2f * t).toFloat() - 1f)
                0.55f * sin(2 * PI * phase).toFloat() * (if (f > 0) 1f else 0f)
            }
        },
        Fx("🥁 Drum Roll") {
            val rnd = Random(7)
            pcm(1.8f) { t, i ->
                val burst = (t * 28f) % 1f
                val rise = (t / 1.6f).coerceAtMost(1f)
                if (t < 1.5f) (rnd.nextFloat() * 2f - 1f) * exp(-burst * 6f) * (0.25f + 0.6f * rise)
                else {
                    val tt = t - 1.5f
                    (tone(110f, tt) * 0.8f + (rnd.nextFloat() * 2f - 1f) * 0.4f) * exp(-tt * 9f)
                }
            }
        },
        Fx("🔔 Ding") {
            pcm(1.2f) { t, _ ->
                (tone(1318f, t) * 0.6f + tone(2636f, t) * 0.25f) * exp(-t * 3.5f)
            }
        },
        Fx("🎮 Level Up") {
            val notes = floatArrayOf(523f, 659f, 784f, 1047f)
            pcm(0.9f) { t, _ ->
                val idx = (t / 0.14f).toInt().coerceAtMost(notes.size - 1)
                val lt = t - idx * 0.14f
                val tail = if (idx == notes.size - 1) exp(-lt * 3f) else exp(-lt * 8f)
                0.35f * square(notes[idx], t) * tail
            }
        },
        Fx("😢 Sad") {
            val notes = floatArrayOf(392f, 370f, 349f, 262f)
            pcm(1.8f) { t, _ ->
                val idx = (t / 0.4f).toInt().coerceAtMost(3)
                val lt = t - idx * 0.4f
                val len = if (idx == 3) 0.6f else 0.4f
                val f = if (idx == 3) notes[3] * (1f - 0.15f * ((lt / len).coerceAtMost(1f))) else notes[idx]
                0.4f * saw(f, t) * exp(-lt * 2f)
            }
        },
        Fx("👏 Claps") {
            val rnd = Random(11)
            val starts = floatArrayOf(0f, 0.12f, 0.23f, 0.37f, 0.5f, 0.58f, 0.71f, 0.85f, 0.93f, 1.05f)
            pcm(1.4f) { t, _ ->
                var s = 0f
                for (st in starts) if (t >= st) s += exp(-(t - st) * 40f)
                (rnd.nextFloat() * 2f - 1f) * s.coerceAtMost(1.2f) * 0.6f
            }
        },
        Fx("💥 Boom") {
            val rnd = Random(3)
            pcm(1.3f) { t, _ ->
                val f = 140f * exp(-t * 2.2f) + 35f
                (tone(f, t) * 0.9f + (rnd.nextFloat() * 2f - 1f) * 0.3f * exp(-t * 14f)) * exp(-t * 2.6f)
            }
        }
    )

    fun play(fx: Fx, volume: Float) {
        Thread {
            try {
                val data = fx.gen()
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SR)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(data.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.write(data, 0, data.size)
                track.setVolume(volume.coerceIn(0.2f, 1f))
                track.play()
                Thread.sleep(data.size * 1000L / SR + 250)
                track.release()
            } catch (e: Exception) {
                // ignore
            }
        }.start()
    }
}
