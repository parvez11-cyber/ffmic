package com.ffmicplayer

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.audiofx.PresetReverb
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.AnimatorSet
import android.animation.ValueAnimator
import android.graphics.BitmapFactory
import android.graphics.Outline
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import java.io.File
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.switchmaterial.SwitchMaterial
import com.topjohnwu.superuser.Shell

class MainActivity : AppCompatActivity(), PlayerHub.Listener {

    // UI
    private lateinit var tvRootStatus: TextView
    private lateinit var tvNowPlaying: TextView
    private lateinit var switchRouting: SwitchMaterial
    private lateinit var switchFloating: SwitchMaterial
    private lateinit var btnPlay: ImageButton
    private lateinit var btnPrev: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var seekBarProgress: SeekBar
    private lateinit var seekBarVolume: SeekBar
    private lateinit var seekBarBass: SeekBar
    private lateinit var seekBarVirtualizer: SeekBar
    private lateinit var spinnerVoice: Spinner
    private lateinit var spinnerEqPreset: Spinner
    private lateinit var spinnerReverb: Spinner
    private lateinit var rvSongs: RecyclerView
    private lateinit var tvCurrentTime: TextView
    private lateinit var tvTotalTime: TextView
    private lateinit var tvRoutingStatus: TextView
    private lateinit var layoutEqBands: LinearLayout
    private lateinit var btnPickFile: Button
    private lateinit var btnAddUrl: Button
    private lateinit var progressDownload: ProgressBar
    private lateinit var tvDownloadStatus: TextView

    private lateinit var songAdapter: SongAdapter
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy {
        getSharedPreferences(AudioRoutingService.PREFS, MODE_PRIVATE)
    }

    private var deviceSongs: List<Song> = emptyList()
    private var addedSongs: List<Song> = emptyList()

    // programmatic UI update-er somoy listener skip korar jonno
    private var uiGuard = false
    private var appliedEqPos = 0
    private var appliedReverbPos = 0
    private var pendingFloating = false
    private var downloading = false

    private val reverbOptions = listOf(
        "None", "Small Room", "Medium Room", "Large Room", "Medium Hall", "Large Hall", "Plate"
    )
    private val reverbPresets: List<Short> = listOf(
        PresetReverb.PRESET_NONE,
        PresetReverb.PRESET_SMALLROOM,
        PresetReverb.PRESET_MEDIUMROOM,
        PresetReverb.PRESET_LARGEROOM,
        PresetReverb.PRESET_MEDIUMHALL,
        PresetReverb.PRESET_LARGEHALL,
        PresetReverb.PRESET_PLATE
    )

    // ---------- Activity result launchers ----------

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            onPermissionsReady()
        }

    private val pickAudioLauncher =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNullOrEmpty()) return@registerForActivityResult
            Thread {
                val newSongs = uris.mapNotNull { SongRepository.addPicked(this, it) }
                runOnUiThread {
                    if (newSongs.isEmpty()) {
                        toast("File open kora gelo na")
                    } else {
                        addedSongs = (newSongs + addedSongs).distinctBy { it.path }
                        refreshSongList()
                        toast("${newSongs.size}ta file add hoyeche")
                    }
                }
            }.start()
        }

    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri == null) return@registerForActivityResult
            Thread {
                val ok = try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        File(filesDir, "profile.img").outputStream().use { input.copyTo(it) }
                    }
                    true
                } catch (e: Exception) { false }
                runOnUiThread {
                    if (ok) loadProfileImage() else toast("Photo load kora gelo na")
                }
            }.start()
        }

    private var searchQuery = ""

    private fun currentShownIndex(): Int {
        val path = PlayerHub.currentSong()?.path ?: return -1
        return songAdapter.getSongs().indexOfFirst { it.path == path }
    }

    private fun setupExtras() {
        val d = resources.displayMetrics.density
        fun chip(v: TextView, active: Boolean) {
            v.background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = 12 * d
                setColor(if (active) 0xFF0B6B7A.toInt() else 0xFF222B36.toInt())
                setStroke((1 * d).toInt(), if (active) 0xFF00E5FF.toInt() else 0xFF33404F.toInt())
            }
        }
        // Shuffle / Repeat
        val btnShuffle = findViewById<TextView>(R.id.btnShuffle)
        val btnRepeat = findViewById<TextView>(R.id.btnRepeat)
        fun syncModes() {
            btnShuffle.text = if (PlayerHub.shuffle) "🔀 Shuffle: ON" else "🔀 Shuffle: OFF"
            chip(btnShuffle, PlayerHub.shuffle)
            btnRepeat.text = when (PlayerHub.repeatMode) {
                0 -> "🔁 Repeat: Off"; 2 -> "🔂 Repeat: One"; else -> "🔁 Repeat: All"
            }
            chip(btnRepeat, PlayerHub.repeatMode != 0)
        }
        btnShuffle.setOnClickListener { PlayerHub.shuffle = !PlayerHub.shuffle; syncModes() }
        btnRepeat.setOnClickListener { PlayerHub.repeatMode = (PlayerHub.repeatMode + 1) % 3; syncModes() }
        syncModes()

        // Speed
        val tvSpeed = findViewById<TextView>(R.id.tvSpeed)
        findViewById<SeekBar>(R.id.seekBarSpeed).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                val sp = 0.5f + progress / 100f
                tvSpeed.text = "⏩ Speed: %.2fx".format(sp)
                if (fromUser) PlayerHub.setSpeed(sp)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // Loud boost
        val tvLoud = findViewById<TextView>(R.id.tvLoud)
        findViewById<SeekBar>(R.id.seekBarLoud).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                tvLoud.text = "📢 Loud Boost: $progress%"
                if (fromUser) PlayerHub.setLoudness(progress * 8)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // Sleep timer
        val sleepOptions = listOf("Off", "15 min", "30 min", "45 min", "60 min", "90 min")
        val sleepMinutes = listOf(0, 15, 30, 45, 60, 90)
        val spinnerSleep = findViewById<Spinner>(R.id.spinnerSleep)
        spinnerSleep.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, sleepOptions)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        spinnerSleep.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                PlayerHub.setSleepTimer(sleepMinutes[pos])
                if (pos > 0) toast("😴 ${sleepOptions[pos]} pore gaan bondho hobe")
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        // Soundboard
        val grid = findViewById<android.widget.GridLayout>(R.id.soundboardGrid)
        SoundBoard.effects.forEach { fx ->
            val b = TextView(this).apply {
                text = fx.label
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 14f
                gravity = android.view.Gravity.CENTER
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = 14 * d
                    setColor(0xFF222B36.toInt())
                    setStroke((1 * d).toInt(), 0xFF3A4A5C.toInt())
                }
                setOnClickListener {
                    animate().scaleX(0.92f).scaleY(0.92f).setDuration(70).withEndAction {
                        animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    }.start()
                    SoundBoard.play(fx, PlayerHub.volume)
                }
            }
            val lp = android.widget.GridLayout.LayoutParams(
                android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f),
                android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f)
            ).apply {
                width = 0
                height = (52 * d).toInt()
                setMargins((4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt())
            }
            grid.addView(b, lp)
        }

        // Search
        findViewById<EditText>(R.id.etSearch).addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                searchQuery = s?.toString() ?: ""
                refreshSongList()
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    // ---------- Root / No-Root mode ----------

    private fun setupModeSelector() {
        val group = findViewById<android.widget.RadioGroup>(R.id.radioMode)
        val useRoot = prefs.getBoolean("use_root", true)
        group.check(if (useRoot) R.id.rbRoot else R.id.rbNoRoot)
        applyModeUi(useRoot)
        group.setOnCheckedChangeListener { _, id ->
            val root = id == R.id.rbRoot
            if (root == prefs.getBoolean("use_root", true)) return@setOnCheckedChangeListener
            prefs.edit().putBoolean("use_root", root).apply()
            applyModeUi(root)
            if (PlayerHub.routingOn) {
                PlayerHub.setRouting(false)
                toast("Mode bodleche — Virtual Mic abar ON koro")
            }
        }
    }

    private fun applyModeUi(root: Boolean) {
        findViewById<View>(R.id.rootOnlyTools).visibility = if (root) View.VISIBLE else View.GONE
        findViewById<TextView>(R.id.tvModeHint).text = if (root) {
            "Root phone-e: music shorashori mic-e mishe jay (Magisk permission Grant koro). Root na thakle auto Speaker Mode-e jabe."
        } else {
            "Root chhara: music speaker diye bajbe, game-er mic sheta tule nibe. Headphone khulo, media volume full koro, ar sob phone-e kaj kore."
        }
    }

    // ---------- Extra graphics ----------

    private val noteHandler = Handler(Looper.getMainLooper())
    private val noteSymbols = listOf("♪", "♫", "♬", "🎵", "🎶")
    private val noteRunnable = object : Runnable {
        override fun run() {
            if (PlayerHub.isPlaying() || PlayerHub.routingOn) spawnNote()
            noteHandler.postDelayed(this, 450)
        }
    }

    private fun spawnNote() {
        val frame = findViewById<FrameLayout>(R.id.headerFrame)
        val d = resources.displayMetrics.density
        val tv = TextView(this).apply {
            text = noteSymbols.random()
            textSize = (14 + (0..10).random()).toFloat()
            setTextColor(listOf(0xFF00E5FF.toInt(), 0xFF7B61FF.toInt(), 0xFFFF6B00.toInt(), 0xFF1EE06A.toInt()).random())
            alpha = 0f
        }
        val lp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = android.view.Gravity.CENTER
            leftMargin = ((-40..40).random() * d).toInt()
        }
        frame.addView(tv, lp)
        val rise = ((70..95).random() * d)
        tv.animate().translationY(-rise).translationXBy(((-30..30).random() * d))
            .alpha(0.9f).setDuration(600).withEndAction {
                tv.animate().alpha(0f).setDuration(900).withEndAction { frame.removeView(tv) }.start()
            }.start()
    }

    private fun setupExtraGraphics() {
        // Avatar border-er rong dhire dhire bodlay
        val img = findViewById<ImageView>(R.id.imgProfile)
        val bg = img.background.mutate() as android.graphics.drawable.GradientDrawable
        val colors = intArrayOf(0xFF00E5FF.toInt(), 0xFF7B61FF.toInt(), 0xFFFF6B00.toInt(), 0xFF00E5FF.toInt())
        ValueAnimator.ofFloat(0f, 3f).apply {
            duration = 9000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                val i = f.toInt().coerceAtMost(2)
                val c = android.animation.ArgbEvaluator().evaluate(f - i, colors[i], colors[i + 1]) as Int
                bg.setStroke((3 * resources.displayMetrics.density).toInt(), c)
            }
            start()
        }
        // Avatar halka halka shash nay
        ObjectAnimator.ofPropertyValuesHolder(
            img,
            android.animation.PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.05f),
            android.animation.PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.05f)
        ).apply {
            duration = 1800
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
        // Play button-e press animation
        btnPlay.setOnTouchListener { v, ev ->
            when (ev.action) {
                android.view.MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.86f).scaleY(0.86f).setDuration(90).start()
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
        noteHandler.post(noteRunnable)
    }

    private val waveAnimators = mutableListOf<Animator>()
    private var wavesRunning = false

    private fun setupProfileAndAnimations() {
        val img = findViewById<ImageView>(R.id.imgProfile)
        img.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        img.clipToOutline = true
        img.setOnClickListener { pickImageLauncher.launch("image/*") }
        loadProfileImage()

        // Card-gulo ek ek kore bhese uthbe
        val container = (findViewById<ScrollView>(R.id.rootScroll).getChildAt(0) as LinearLayout)
        for (i in 0 until container.childCount) {
            val v = container.getChildAt(i)
            if (v.background != null) {
                v.alpha = 0f
                v.translationY = 60f
                v.animate().alpha(1f).translationY(0f)
                    .setStartDelay(120L * i).setDuration(450).start()
            }
        }
    }

    private fun loadProfileImage() {
        val img = findViewById<ImageView>(R.id.imgProfile)
        val f = File(filesDir, "profile.img")
        if (!f.exists()) {
            img.setImageResource(R.drawable.profile_default)
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            return
        }
        try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, opts)
            var sample = 1
            while (opts.outWidth / sample > 600) sample *= 2
            val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
            if (bmp != null) {
                img.scaleType = ImageView.ScaleType.CENTER_CROP
                img.setImageBitmap(bmp)
            }
        } catch (e: Exception) {
            toast("Photo dekhano gelo na")
        }
    }

    private fun setWaves(on: Boolean) {
        if (on == wavesRunning) return
        wavesRunning = on
        waveAnimators.forEach { it.cancel() }
        waveAnimators.clear()
        val rings = listOf(R.id.wave1, R.id.wave2, R.id.wave3).map { findViewById<View>(it) }
        if (!on) { rings.forEach { it.alpha = 0f; it.scaleX = 1f; it.scaleY = 1f }; return }
        rings.forEachIndexed { i, v ->
            val set = AnimatorSet()
            val sx = ObjectAnimator.ofFloat(v, View.SCALE_X, 1f, 1.65f)
            val sy = ObjectAnimator.ofFloat(v, View.SCALE_Y, 1f, 1.65f)
            val a = ObjectAnimator.ofFloat(v, View.ALPHA, 0.8f, 0f)
            listOf(sx, sy, a).forEach {
                it.repeatCount = ValueAnimator.INFINITE
                it.duration = 2100
                it.interpolator = LinearInterpolator()
                it.startDelay = 700L * i
            }
            set.playTogether(sx, sy, a)
            set.start()
            waveAnimators.add(set)
        }
    }

    private val progressRunnable = object : Runnable {
        override fun run() {
            if (PlayerHub.isPlaying()) {
                val pos = PlayerHub.position()
                val dur = PlayerHub.duration()
                if (seekBarProgress.max != dur) seekBarProgress.max = dur
                seekBarProgress.progress = pos
                tvCurrentTime.text = formatMs(pos)
                tvTotalTime.text = formatMs(dur)
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Android 15: edge-to-edge force hoy, tai nijera insets handle kori
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)
        applyWindowInsets()

        // Init root shell first
        Shell.enableVerboseLogging = BuildConfig.DEBUG
        Shell.setDefaultBuilder(
            Shell.Builder.create()
                .setFlags(Shell.FLAG_REDIRECT_STDERR)
                .setTimeout(10)
        )

        PlayerHub.init(this)
        initViews()
        setupProfileAndAnimations()
        setupModeSelector()
        setupExtraGraphics()
        setupExtras()
        startRoutingService()
        checkPermissions()
    }

    private fun applyWindowInsets() {
        val root = findViewById<View>(R.id.rootScroll)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }
        // dark background, tai status bar icon shada
        WindowCompat.getInsetsController(window, root).isAppearanceLightStatusBars = false
    }

    private fun initViews() {
        tvRootStatus       = findViewById(R.id.tvRootStatus)
        tvNowPlaying       = findViewById(R.id.tvNowPlaying)
        switchRouting      = findViewById(R.id.switchRouting)
        switchFloating     = findViewById(R.id.switchFloating)
        btnPlay            = findViewById(R.id.btnPlay)
        btnPrev            = findViewById(R.id.btnPrev)
        btnNext            = findViewById(R.id.btnNext)
        seekBarProgress    = findViewById(R.id.seekBarProgress)
        seekBarVolume      = findViewById(R.id.seekBarVolume)
        seekBarBass        = findViewById(R.id.seekBarBass)
        seekBarVirtualizer = findViewById(R.id.seekBarVirtualizer)
        spinnerVoice       = findViewById(R.id.spinnerVoice)
        spinnerEqPreset    = findViewById(R.id.spinnerEqPreset)
        spinnerReverb      = findViewById(R.id.spinnerReverb)
        rvSongs            = findViewById(R.id.rvSongs)
        tvCurrentTime      = findViewById(R.id.tvCurrentTime)
        tvTotalTime        = findViewById(R.id.tvTotalTime)
        tvRoutingStatus    = findViewById(R.id.tvRoutingStatus)
        layoutEqBands      = findViewById(R.id.layoutEqBands)
        btnPickFile        = findViewById(R.id.btnPickFile)
        btnAddUrl          = findViewById(R.id.btnAddUrl)
        progressDownload   = findViewById(R.id.progressDownload)
        tvDownloadStatus   = findViewById(R.id.tvDownloadStatus)

        // RecyclerView
        songAdapter = SongAdapter(emptyList()) { song, _ ->
            val idx = PlayerHub.songs.indexOfFirst { it.path == song.path }
            if (idx >= 0) PlayerHub.play(idx)
        }
        rvSongs.layoutManager = LinearLayoutManager(this)
        rvSongs.isNestedScrollingEnabled = true
        rvSongs.setOnTouchListener { v, ev ->
            when (ev.action) {
                android.view.MotionEvent.ACTION_DOWN, android.view.MotionEvent.ACTION_MOVE ->
                    v.parent.requestDisallowInterceptTouchEvent(true)
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                    v.parent.requestDisallowInterceptTouchEvent(false)
            }
            false
        }
        rvSongs.adapter = songAdapter

        // Play/Pause, next, prev
        btnPlay.setOnClickListener { PlayerHub.togglePlayPause() }
        btnPrev.setOnClickListener { PlayerHub.previous() }
        btnNext.setOnClickListener { PlayerHub.next() }

        // Seek
        seekBarProgress.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) PlayerHub.seekTo(progress)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // Volume
        seekBarVolume.max = 100
        seekBarVolume.progress = (PlayerHub.volume * 100).toInt()
        seekBarVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                PlayerHub.setVolume(progress / 100f)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // Bass
        seekBarBass.max = 1000
        seekBarBass.progress = 0
        seekBarBass.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                PlayerHub.equalizer?.setBassBoost(progress)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // Virtualizer
        seekBarVirtualizer.max = 1000
        seekBarVirtualizer.progress = 0
        seekBarVirtualizer.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                PlayerHub.equalizer?.setVirtualizer(progress)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // Route mode spinner (kon route-e music mic-e jabe)
        val spinnerRoute = findViewById<Spinner>(R.id.spinnerRouteMode)
        spinnerRoute.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_item,
            listOf("Route: Shob (UL4 + UL2)", "Route: shudhu UL4", "Route: shudhu UL2")
        ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        val savedMode = prefs.getInt("route_mode", 0)
        RootAudioRouter.routeMode = savedMode
        spinnerRoute.setSelection(savedMode)
        spinnerRoute.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                if (pos == RootAudioRouter.routeMode) return
                RootAudioRouter.routeMode = pos
                prefs.edit().putInt("route_mode", pos).apply()
                toast("Route mode bodleche — Virtual Mic OFF kore abar ON koro")
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        // Voice changer spinner
        val voices = VoicePreset.values().map { it.label }
        spinnerVoice.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, voices)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        spinnerVoice.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                if (pos == PlayerHub.voice.ordinal) return
                PlayerHub.setVoice(VoicePreset.values()[pos])
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        // EQ Presets spinner
        val presets = EqualizerManager.EqPreset.values().map { it.displayName }
        spinnerEqPreset.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, presets)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        spinnerEqPreset.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                if (pos == appliedEqPos) return
                appliedEqPos = pos
                val preset = EqualizerManager.EqPreset.values()[pos]
                try {
                    PlayerHub.equalizer?.applyPreset(preset)
                } catch (e: Exception) {
                    // device eq support korena
                }
                seekBarBass.progress = preset.bassBoost
                seekBarVirtualizer.progress = preset.virtualizer
                buildEqBandSliders()
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        // Reverb spinner
        spinnerReverb.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, reverbOptions)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        spinnerReverb.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                if (pos == appliedReverbPos) return
                appliedReverbPos = pos
                PlayerHub.equalizer?.setReverb(reverbPresets.getOrElse(pos) { PresetReverb.PRESET_NONE })
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        // Routing switch
        switchRouting.setOnCheckedChangeListener { _, isChecked ->
            if (!uiGuard) PlayerHub.setRouting(isChecked)
        }

        // Floating icon switch
        switchFloating.setOnCheckedChangeListener { _, isChecked ->
            if (!uiGuard) setFloatingEnabled(isChecked)
        }

        // Song input
        btnPickFile.setOnClickListener { pickAudioLauncher.launch(arrayOf("audio/*")) }
        btnAddUrl.setOnClickListener { showUrlDialog() }

        findViewById<Button>(R.id.btnDiagnose).setOnClickListener { runDiagnose() }
        findViewById<Button>(R.id.btnProbe).setOnClickListener { runProbe() }
        findViewById<Button>(R.id.btnDump).setOnClickListener {
            Thread {
                val r = try { RootAudioRouter.dumpFull() } catch (e: Exception) { "Error: ${e.message}" }
                runOnUiThread { showReport("Download folder-e ffmic_*.txt file toiri hoyeche:\n$r") }
            }.start()
        }
    }

    // ---------- Lifecycle: hub-er sathe sync ----------

    override fun onStart() {
        super.onStart()
        PlayerHub.addListener(this)
        syncAllUi()
        handler.removeCallbacks(progressRunnable)
        handler.post(progressRunnable)
    }

    override fun onResume() {
        super.onResume()
        if (pendingFloating) {
            pendingFloating = false
            if (Settings.canDrawOverlays(this)) {
                setFloatingEnabled(true)
            } else {
                toast("Overlay permission dewa hoyni")
            }
        }
        syncFloatingUi()
    }

    override fun onDestroy() {
        waveAnimators.forEach { it.cancel() }
        eqAnims.forEach { it.cancel() }
        noteHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onStop() {
        PlayerHub.removeListener(this)
        handler.removeCallbacks(progressRunnable)
        super.onStop()
    }

    // ---------- PlayerHub.Listener ----------

    override fun onTrackChanged() {
        syncTrackUi()
        buildEqBandSliders()
    }

    override fun onPlayStateChanged() = syncPlayIcon()
    override fun onVoiceChanged() = syncVoiceUi()
    override fun onRoutingChanged() = syncRoutingUi()
    override fun onMessage(msg: String) = toast(msg)

    private fun syncAllUi() {
        syncTrackUi()
        syncPlayIcon()
        syncVoiceUi()
        syncRoutingUi()
        syncFloatingUi()
        buildEqBandSliders()
    }

    private fun syncTrackUi() {
        val song = PlayerHub.currentSong()
        tvNowPlaying.text = if (song != null) "${song.title} — ${song.artist}" else "Kono song select kora hoyni"
        songAdapter.setCurrentPlaying(currentShownIndex())
        val dur = PlayerHub.duration()
        seekBarProgress.max = if (dur > 0) dur else 1
        seekBarProgress.progress = PlayerHub.position()
        tvCurrentTime.text = formatMs(PlayerHub.position())
        tvTotalTime.text = formatMs(dur)
    }

    private val eqAnims = mutableListOf<Animator>()

    private fun setEqualizer(on: Boolean) {
        val bars = findViewById<LinearLayout>(R.id.eqBars)
        eqAnims.forEach { it.cancel() }
        eqAnims.clear()
        for (i in 0 until bars.childCount) {
            val v = bars.getChildAt(i)
            v.pivotY = (26 * resources.displayMetrics.density)
            if (!on) { v.scaleY = 0.15f; continue }
            val a = ObjectAnimator.ofFloat(v, View.SCALE_Y, 0.2f, 1f).apply {
                duration = 350L + (i * 97L) % 300
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                startDelay = i * 60L
                start()
            }
            eqAnims.add(a)
        }
    }

    private fun syncPlayIcon() {
        setEqualizer(PlayerHub.isPlaying())
        btnPlay.setImageResource(
            if (PlayerHub.isPlaying()) android.R.drawable.ic_media_pause
            else android.R.drawable.ic_media_play
        )
    }

    private fun syncVoiceUi() {
        val voice = PlayerHub.voice
        appliedEqPos = voice.eq.ordinal
        appliedReverbPos = reverbPresets.indexOf(voice.reverb).coerceAtLeast(0)
        spinnerVoice.setSelection(voice.ordinal)
        spinnerEqPreset.setSelection(appliedEqPos)
        spinnerReverb.setSelection(appliedReverbPos)
        seekBarBass.progress = voice.eq.bassBoost
        seekBarVirtualizer.progress = voice.eq.virtualizer
        buildEqBandSliders()
    }

    private fun syncRoutingUi() {
        val busy = PlayerHub.routingBusy
        val on = if (busy) PlayerHub.routingTarget else PlayerHub.routingOn
        uiGuard = true
        switchRouting.isChecked = on
        switchRouting.isEnabled = !busy
        uiGuard = false
        setWaves(on)

        when {
            busy -> {
                tvRoutingStatus.text = "⏳ Virtual Mic: cholche..."
                tvRoutingStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_orange_light))
            }
            on && PlayerHub.routingSpeaker -> {
                tvRoutingStatus.text = "🔊 Speaker Mode ON — headphone khulo, volume barao; game-er mic speaker theke gaan nibe"
                tvRoutingStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light))
            }
            on -> {
                tvRoutingStatus.text = "🟢 Virtual Mic: ON — teammates sunte parbe"
                tvRoutingStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light))
            }
            else -> {
                tvRoutingStatus.text = "⚫ Virtual Mic: OFF"
                tvRoutingStatus.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray))
            }
        }
    }

    private fun syncFloatingUi() {
        val on = prefs.getBoolean(AudioRoutingService.KEY_FLOATING, false) &&
            Settings.canDrawOverlays(this)
        uiGuard = true
        // overlay permission-er jonno Settings-e giye ferar somoy switch on-i thake
        switchFloating.isChecked = on || pendingFloating
        uiGuard = false
    }

    private fun buildEqBandSliders() {
        layoutEqBands.removeAllViews()
        val eq = PlayerHub.equalizer ?: return
        val freqs = eq.getBandFrequencies()
        val levels = eq.getBandLevels()
        val range = eq.getLevelRange()

        freqs.forEachIndexed { i, freq ->
            val label = TextView(this).apply {
                text = "${freq}Hz"
                setTextColor(ContextCompat.getColor(context, android.R.color.white))
                textAlignment = View.TEXT_ALIGNMENT_CENTER
            }
            val sb = SeekBar(this).apply {
                max = range.second - range.first
                progress = levels.getOrElse(i) { 0 } - range.first
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                        if (fromUser) eq.setBandLevel(i, p + range.first)
                    }
                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) {}
                })
            }
            layoutEqBands.addView(label)
            layoutEqBands.addView(sb)
        }
    }

    // ---------- Songs ----------

    private fun refreshSongList() {
        val all = addedSongs + deviceSongs.filter { d -> addedSongs.none { it.path == d.path } }
        PlayerHub.setSongs(all)
        val q = searchQuery.trim().lowercase()
        val shown = if (q.isEmpty()) all else all.filter {
            it.title.lowercase().contains(q) || it.artist.lowercase().contains(q)
        }
        songAdapter.updateSongs(shown)
        songAdapter.setCurrentPlaying(currentShownIndex())
    }

    private fun loadAllSongs() {
        Thread {
            val added = SongRepository.loadAdded(this)
            val device = if (hasMediaPermission()) SongRepository.loadDeviceSongs(this) else emptyList()
            runOnUiThread {
                addedSongs = added
                deviceSongs = device
                refreshSongList()
                val total = addedSongs.size + deviceSongs.size
                if (total == 0) {
                    toast("Kono song nai — Local File ba Online Link diye add koro")
                } else {
                    toast("${total}ta song loaded")
                }
            }
        }.start()
    }

    private fun showUrlDialog() {
        val input = EditText(this).apply {
            hint = "Ekta link = ekta line. Onek link ekshathe paste koro\n(TikTok / .mp3 / .m4a ...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(false)
            minLines = 5
            maxLines = 8
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
            isVerticalScrollBarEnabled = true
            setHorizontallyScrolling(false)
            setOnTouchListener { v, ev ->
                v.parent.requestDisallowInterceptTouchEvent(true)
                if (ev.action == android.view.MotionEvent.ACTION_UP) v.performClick()
                false
            }
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val scroll = ScrollView(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Online link theke song")
            .setMessage("TikTok link dile tar audio download hobe. Onek link dile ek ek kore shob download hobe.")
            .setView(scroll)
            .setPositiveButton("Download") { _, _ ->
                val links = input.text.toString().split(Regex("\\s+"))
                    .map { it.trim() }.filter { it.startsWith("http") }
                if (links.isNotEmpty()) startDownloadAll(links)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startDownloadAll(links: List<String>) {
        if (downloading) {
            toast("Ekta download cholche, ektu opekkha koro")
            return
        }
        downloading = true
        progressDownload.visibility = View.VISIBLE
        progressDownload.isIndeterminate = true
        tvDownloadStatus.visibility = View.VISIBLE
        Thread {
            var ok = 0
            val errors = mutableListOf<String>()
            links.forEachIndexed { idx, link ->
                val label = "${idx + 1}/${links.size}"
                try {
                    runOnUiThread { tvDownloadStatus.text = "[$label] link porchi..." }
                    val direct = if (SongRepository.isTikTok(link)) SongRepository.resolveTikTok(link) else link
                    val song = SongRepository.download(this, direct) { pct, bytes ->
                        runOnUiThread {
                            if (pct >= 0) {
                                progressDownload.isIndeterminate = false
                                progressDownload.progress = pct
                                tvDownloadStatus.text = "[$label] Downloading... $pct%"
                            } else {
                                tvDownloadStatus.text = "[$label] Downloading... ${bytes / 1024} KB"
                            }
                        }
                    }
                    ok++
                    runOnUiThread {
                        addedSongs = (listOf(song) + addedSongs).distinctBy { it.path }
                        refreshSongList()
                    }
                } catch (e: Exception) {
                    errors.add("[$label] ${e.message ?: "fail"}")
                }
            }
            runOnUiThread {
                tvDownloadStatus.text = "✅ $ok/${links.size} ta add hoyeche" +
                    (if (errors.isNotEmpty()) "\n❌ " + errors.joinToString("\n❌ ") else "")
                downloading = false
                progressDownload.visibility = View.GONE
            }
        }.start()
    }

    private fun startDownload(url: String) {
        if (downloading) {
            toast("Ekta download cholche, ektu opekkha koro")
            return
        }
        downloading = true
        progressDownload.visibility = View.VISIBLE
        progressDownload.isIndeterminate = true
        tvDownloadStatus.visibility = View.VISIBLE
        tvDownloadStatus.text = "Download shuru hocche..."

        Thread {
            try {
                val song = SongRepository.download(this, url) { pct, bytes ->
                    runOnUiThread {
                        if (pct >= 0) {
                            progressDownload.isIndeterminate = false
                            progressDownload.progress = pct
                            tvDownloadStatus.text = "Downloading... $pct%"
                        } else {
                            tvDownloadStatus.text = "Downloading... ${bytes / 1024} KB"
                        }
                    }
                }
                runOnUiThread {
                    addedSongs = (listOf(song) + addedSongs).distinctBy { it.path }
                    refreshSongList()
                    tvDownloadStatus.text = "✅ Added: ${song.title}"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    tvDownloadStatus.text = "❌ ${e.message ?: "Download hoyni"}"
                }
            } finally {
                runOnUiThread {
                    downloading = false
                    progressDownload.visibility = View.GONE
                }
            }
        }.start()
    }

    // ---------- Root diagnose ----------

    private fun runDiagnose() {
        toast("Check cholche...")
        Thread {
            val report = try {
                RootAudioRouter.diagnose()
            } catch (e: Exception) {
                "Diagnose error: ${e.message}"
            }
            runOnUiThread { showReport(report) }
        }.start()
    }

    private fun runProbe() {
        toast("Ekhon Free Fire-e giye 20 sec mic chalu rakho (kotha bolo), tarpor app-e ferot esho")
        Thread {
            val report = try {
                RootAudioRouter.probeCapture(20_000)
            } catch (e: Exception) {
                "Probe error: ${e.message}"
            }
            runOnUiThread { showReport(report) }
        }.start()
    }

    private fun showReport(report: String) {
        val tv = TextView(this).apply {
            text = report
            textSize = 12f
            setTextIsSelectable(true)
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
        }
        val scroll = ScrollView(this).apply { addView(tv) }
        AlertDialog.Builder(this)
            .setTitle("Root Diagnose")
            .setView(scroll)
            .setPositiveButton("Copy") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("diagnose", report))
                toast("Copy hoyeche")
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ---------- Floating icon ----------

    private fun setFloatingEnabled(enable: Boolean) {
        if (enable) {
            if (!Settings.canDrawOverlays(this)) {
                pendingFloating = true
                toast("\"Display over other apps\" permission on koro, tarpor ferot esho")
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
                return
            }
            prefs.edit().putBoolean(AudioRoutingService.KEY_FLOATING, true).apply()
            sendServiceAction(AudioRoutingService.ACTION_SHOW_FLOATING)
        } else {
            prefs.edit().putBoolean(AudioRoutingService.KEY_FLOATING, false).apply()
            sendServiceAction(AudioRoutingService.ACTION_HIDE_FLOATING)
        }
        syncFloatingUi()
    }

    private fun startRoutingService() {
        ContextCompat.startForegroundService(this, Intent(this, AudioRoutingService::class.java))
    }

    private fun sendServiceAction(action: String) {
        ContextCompat.startForegroundService(
            this,
            Intent(this, AudioRoutingService::class.java).setAction(action)
        )
    }

    // ---------- Root + permissions ----------

    private fun checkRootAndUpdateUI() {
        Shell.cmd("id").submit { result ->
            runOnUiThread {
                if (result.isSuccess && result.out.any { it.contains("uid=0") }) {
                    tvRootStatus.text = "✅ Root: Connected"
                    tvRootStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light))
                } else {
                    tvRootStatus.text = "⚠️ Root nai — Speaker Mode e cholbe (speaker → game mic)"
                    tvRootStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_orange_light))
                }
            }
        }
    }

    private fun mediaPermission(): String =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

    private fun hasMediaPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, mediaPermission()) == PackageManager.PERMISSION_GRANTED

    private fun checkPermissions() {
        val perms = mutableListOf(mediaPermission(), Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        } else {
            onPermissionsReady()
        }
    }

    private fun onPermissionsReady() {
        if (!hasMediaPermission()) {
            toast("Storage permission nai — tobe \"Local File\" diye song add korte paro")
        }
        checkRootAndUpdateUI()
        loadAllSongs()
    }

    // ---------- Helpers ----------

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun formatMs(ms: Int): String {
        val totalSec = ms / 1000
        val min = totalSec / 60
        val sec = totalSec % 60
        return "%d:%02d".format(min, sec)
    }

    // Player ar floating icon service-er sathe cholte thake, tai ekhane release kori na
}
