package com.ffmicplayer

import android.media.audiofx.PresetReverb

/**
 * Voice changer presets. Player-er audio (jeta virtual mic-e jacche) er
 * pitch + EQ + reverb change kore.
 */
enum class VoicePreset(
    val label: String,
    val pitch: Float,
    val eq: EqualizerManager.EqPreset,
    val reverb: Short
) {
    NORMAL("Normal", 1.00f, EqualizerManager.EqPreset.NORMAL, PresetReverb.PRESET_NONE),
    DEEP("Deep", 0.78f, EqualizerManager.EqPreset.BASS_BOOST, PresetReverb.PRESET_NONE),
    HIGH("High", 1.30f, EqualizerManager.EqPreset.VOCAL, PresetReverb.PRESET_NONE),
    CHIPMUNK("Chipmunk", 1.65f, EqualizerManager.EqPreset.TREBLE, PresetReverb.PRESET_NONE),
    ECHO("Echo", 1.00f, EqualizerManager.EqPreset.NORMAL, PresetReverb.PRESET_LARGEHALL),
    GIANT("👹 Giant", 0.62f, EqualizerManager.EqPreset.BASS_BOOST, PresetReverb.PRESET_MEDIUMHALL),
    MONSTER("🧟 Monster", 0.70f, EqualizerManager.EqPreset.BASS_BOOST, PresetReverb.PRESET_LARGEROOM),
    GIRL("👧 Girl", 1.42f, EqualizerManager.EqPreset.VOCAL, PresetReverb.PRESET_NONE),
    BABY("👶 Baby", 1.85f, EqualizerManager.EqPreset.TREBLE, PresetReverb.PRESET_SMALLROOM),
    ALIEN("👽 Alien", 1.95f, EqualizerManager.EqPreset.TREBLE, PresetReverb.PRESET_PLATE),
    CAVE("🕳 Cave", 0.90f, EqualizerManager.EqPreset.NORMAL, PresetReverb.PRESET_LARGEHALL),
    STADIUM("🏟 Stadium", 1.00f, EqualizerManager.EqPreset.GAMING, PresetReverb.PRESET_LARGEHALL),
    ROBOT("🤖 Robot", 0.88f, EqualizerManager.EqPreset.RADIO, PresetReverb.PRESET_PLATE),
    RADIO("📻 Radio", 1.00f, EqualizerManager.EqPreset.RADIO, PresetReverb.PRESET_NONE),
    DEMON("😈 Demon", 0.55f, EqualizerManager.EqPreset.BASS_BOOST, PresetReverb.PRESET_PLATE),
    FUNNY("🤪 Funny", 1.58f, EqualizerManager.EqPreset.VOCAL, PresetReverb.PRESET_SMALLROOM)
}
