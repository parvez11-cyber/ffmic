package com.ffmicplayer

import android.util.Log
import com.topjohnwu.superuser.Shell

object RootAudioRouter {

    private const val TAG = "RootAudioRouter"
    private var isRoutingActive = false

    // Check if device supports pcm loopback
    fun isLoopbackSupported(): Boolean {
        val result = Shell.cmd("ls /dev/snd/").exec()
        val output = result.out.joinToString(" ")
        Log.d(TAG, "SND devices: $output")
        return result.isSuccess
    }

    // Load pcm loopback kernel module and create virtual mic
    fun enableVirtualMic(): Boolean {
        if (isRoutingActive) return true

        // Step 1: Try loading snd-aloop kernel module
        val modLoad = Shell.cmd(
            "modprobe snd-aloop || insmod /system/lib/modules/snd-aloop.ko 2>/dev/null || true"
        ).exec()
        Log.d(TAG, "Module load: ${modLoad.out}")

        // Step 2: Check loopback sound card sotti-i ache kina
        val checkLoop = Shell.cmd("grep -i loop /proc/asound/cards").exec()
        val hasLoop = checkLoop.out.any { it.contains("loop", ignoreCase = true) }
        Log.d(TAG, "Loopback device exists: $hasLoop")

        // Step 3: Use tinymix / amixer to route loopback playback -> capture
        // This routes virtual playback device output to virtual capture (mic) input
        val routeResult = Shell.cmd(
            // Try amixer first (most devices)
            "amixer -c 1 sset 'Loopback Mixer' on 2>/dev/null || " +
            // Fallback: tinymix (needs tinymix binary in PATH or /system/bin)
            "tinymix -D 1 set 'Loopback Mixer' 1 2>/dev/null || " +
            "echo 'route_attempted'"
        ).exec()
        Log.d(TAG, "Route result: ${routeResult.out}")

        // Step 4: Set loopback device as default capture source
        val setDefault = Shell.cmd(
            // Try setting via AudioPolicyManager prop
            "setprop ro.audio.monitorOrientation false 2>/dev/null;" +
            // Force mic source to loopback card (card 1 typically after snd-aloop)
            "amixer -c 1 sset 'PCM' 100% 2>/dev/null || true"
        ).exec()
        Log.d(TAG, "Set default: ${setDefault.out}")

        // Age ekhane 'echo route_attempted' diye shob somoy true hoto — ekhon shudhu loopback thakle true
        isRoutingActive = hasLoop
        return isRoutingActive
    }

    // Start piping audio from playback to mic using tee + aplay/arecord trick
    fun startAudioPipe(): Boolean {
        // arecord from default (music output) and pipe to aplay on loopback capture
        // This keeps the pipe alive in background
        val pipe = Shell.cmd(
            "arecord -D hw:0,0 -f cd -t raw 2>/dev/null | " +
            "aplay -D hw:1,1 -f cd 2>/dev/null &"
        ).exec()
        Log.d(TAG, "Pipe started: ${pipe.isSuccess}, out: ${pipe.out}")
        return pipe.isSuccess
    }

    // Loopback card ache kina check kore (system partition-e kono poriborton kore na)
    fun setLoopbackAsMic(): Boolean {
        val result = Shell.cmd(
            "grep -i loop /proc/asound/cards >/dev/null 2>&1 && echo loopback_card_found || echo not_found"
        ).exec()
        Log.d(TAG, "Loopback card check: ${result.out}")
        return result.out.any { it.contains("loopback_card_found") }
    }

    fun disableVirtualMic(): Boolean {
        isRoutingActive = false
        val result = Shell.cmd(
            // Kill any background arecord/aplay pipes
            "pkill -f 'arecord' 2>/dev/null;" +
            "pkill -f 'aplay' 2>/dev/null;" +
            // Unload loopback module
            "rmmod snd_aloop 2>/dev/null || true"
        ).exec()
        Log.d(TAG, "Disabled virtual mic: ${result.out}")
        return result.isSuccess
    }

    fun isRoutingActive() = isRoutingActive

    fun getRootStatus(): String {
        val result = Shell.cmd("id").exec()
        return result.out.firstOrNull() ?: "unknown"
    }

    fun checkRootAccess(): Boolean {
        return Shell.getShell().isRoot
    }

    // Read-only check: phone-e routing-er jonno ki ki ache
    fun diagnose(): String {
        val script = """
            echo "== root =="; id
            echo "== device =="
            getprop ro.product.model; getprop ro.product.manufacturer
            getprop ro.board.platform; getprop ro.build.version.release
            uname -r
            echo "== sound cards =="; cat /proc/asound/cards 2>&1
            echo "== /dev/snd =="; ls /dev/snd 2>&1
            echo "== loaded modules =="; (lsmod 2>&1 | grep -i -E "aloop|snd" ) || echo "none/lsmod nai"
            echo "== kernel config =="; (zcat /proc/config.gz 2>/dev/null | grep -i -E "SND_ALOOP|SND_DUMMY") || echo "config.gz nai"
            echo "== aloop module file =="; (find /vendor/lib/modules /system/lib/modules /lib/modules -iname "*aloop*" 2>/dev/null | head -3) || true
            echo "== tools =="; for t in tinymix amixer tinycap tinyplay aplay arecord; do which ${'$'}t || echo "${'$'}t: nai"; done
            echo "== audio policy =="; ls /vendor/etc/audio_policy_configuration.xml /system/etc/audio_policy_configuration.xml 2>&1
            echo "== hardware =="; getprop ro.hardware; getprop ro.hardware.audio.primary; getprop ro.vendor.mediatek.platform
            echo "== pcm devices =="; cat /proc/asound/pcm 2>&1 | head -40
            echo "== audio files =="; ls /vendor/etc /vendor/etc/audio /system/etc 2>/dev/null | grep -i -E "audio|mixer" | head -20
            echo "== policy: submix/input =="; (dumpsys media.audio_policy 2>&1 | grep -i -E "submix|input device|available input" | head -25) || true
            echo "== mixer controls (UL/DL/loop) =="; (tinymix 2>&1 | grep -i -E "loop|ADDA|UL1|UL2|DL1|I2S|AFE|Mux" | head -50) || echo "tinymix nai"
        """.trimIndent()
        val result = Shell.cmd(script).exec()
        return result.out.joinToString("\n")
    }
}
