package com.ffmicplayer

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/**
 * Screen-er upore (Free Fire-er upore-o) bhasha choto mic icon.
 * Drag kora jay. Tap korle panel khole: Mic ON/OFF, Voice change, play/pause.
 */
class FloatingController(private val context: Context) : PlayerHub.Listener {

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var expanded = false

    private var bubble: TextView? = null
    private var panel: View? = null
    private var toggle: TextView? = null
    private var play: TextView? = null
    private var now: TextView? = null
    private var voiceRow: LinearLayout? = null
    private val chips = mutableListOf<TextView>()

    private val density = context.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    fun isShowing() = root != null

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (root != null) return

        val view = LayoutInflater.from(context).inflate(R.layout.overlay_floating, null)
        bubble = view.findViewById(R.id.fcBubble)
        panel = view.findViewById(R.id.fcPanel)
        toggle = view.findViewById(R.id.fcToggle)
        play = view.findViewById(R.id.fcPlay)
        now = view.findViewById(R.id.fcNow)
        voiceRow = view.findViewById(R.id.fcVoiceRow)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = dp(200)
        }
        params = lp

        buildVoiceChips()

        // Tap = panel khola/bondho, drag = soranu
        bubble?.setOnTouchListener(DragListener())

        toggle?.setOnClickListener {
            if (!PlayerHub.routingBusy) PlayerHub.setRouting(!PlayerHub.routingOn)
        }
        view.findViewById<View>(R.id.fcClose).setOnClickListener { setExpanded(false) }
        view.findViewById<View>(R.id.fcPrev).setOnClickListener { PlayerHub.previous() }
        view.findViewById<View>(R.id.fcNext).setOnClickListener { PlayerHub.next() }
        play?.setOnClickListener { PlayerHub.togglePlayPause() }

        try {
            wm.addView(view, lp)
        } catch (e: Exception) {
            // overlay permission nai ba window add hoyni
            Toast.makeText(context, "Floating icon dekhano gelo na: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }
        root = view
        PlayerHub.addListener(this)
        syncAll()
    }

    fun hide() {
        PlayerHub.removeListener(this)
        root?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
                // already removed
            }
        }
        root = null
        params = null
        expanded = false
        chips.clear()
    }

    // ---------- UI ----------

    private fun buildVoiceChips() {
        val row = voiceRow ?: return
        row.removeAllViews()
        chips.clear()
        VoicePreset.values().forEach { preset ->
            val chip = TextView(context).apply {
                text = preset.label
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(6), dp(10), dp(6))
                setOnClickListener { PlayerHub.setVoice(preset) }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(6) }
            row.addView(chip, lp)
            chips.add(chip)
        }
    }

    private fun pill(color: Int, radiusDp: Int = 16): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(color)
        }

    private fun syncAll() {
        syncVoice()
        syncRouting()
        syncPlayState()
        syncTrack()
    }

    private fun syncVoice() {
        val presets = VoicePreset.values()
        chips.forEachIndexed { i, chip ->
            val selected = presets[i] == PlayerHub.voice
            chip.background = pill(if (selected) Color.parseColor("#00E5FF") else Color.parseColor("#2A313B"))
            chip.setTextColor(if (selected) Color.BLACK else Color.WHITE)
        }
    }

    private fun syncRouting() {
        val busy = PlayerHub.routingBusy
        val on = if (busy) PlayerHub.routingTarget else PlayerHub.routingOn
        toggle?.apply {
            text = if (busy) "..." else if (on) "ON" else "OFF"
            background = pill(
                if (busy) Color.parseColor("#B8860B")
                else if (on) Color.parseColor("#1E9E4A")
                else Color.parseColor("#555F6B")
            )
        }
        // bubble-er rong-o bole dey mic ON/OFF
        bubble?.let { b ->
            b.animate().cancel()
            if (on && !busy) {
                b.animate().scaleX(1.18f).scaleY(1.18f).setDuration(600).withEndAction { pulseBack(b) }.start()
            } else { b.scaleX = 1f; b.scaleY = 1f }
        }
        (bubble?.background as? GradientDrawable)?.setColor(
            if (on) Color.parseColor("#1E9E4A") else Color.parseColor("#555F6B")
        )
    }

    private fun pulseBack(b: View) {
        if (root == null || !PlayerHub.routingOn) { b.scaleX = 1f; b.scaleY = 1f; return }
        b.animate().scaleX(1f).scaleY(1f).setDuration(600).withEndAction {
            if (root != null && PlayerHub.routingOn) {
                b.animate().scaleX(1.18f).scaleY(1.18f).setDuration(600).withEndAction { pulseBack(b) }.start()
            }
        }.start()
    }

    private fun syncPlayState() {
        play?.text = if (PlayerHub.isPlaying()) "⏸" else "▶"
    }

    private fun syncTrack() {
        val s = PlayerHub.currentSong()
        now?.text = s?.title ?: "Kono song select kora hoyni"
    }

    private fun setExpanded(value: Boolean) {
        expanded = value
        panel?.visibility = if (value) View.VISIBLE else View.GONE
        // panel khulle screen-er baire jeno na jay
        root?.post { clampToScreen() }
    }

    private fun clampToScreen() {
        val lp = params ?: return
        val r = root ?: return
        val dm = context.resources.displayMetrics
        val maxX = (dm.widthPixels - r.width).coerceAtLeast(0)
        val maxY = (dm.heightPixels - r.height).coerceAtLeast(0)
        lp.x = lp.x.coerceIn(0, maxX)
        lp.y = lp.y.coerceIn(0, maxY)
        try { wm.updateViewLayout(r, lp) } catch (e: Exception) { /* ignore */ }
    }

    private fun snapToEdge() {
        val lp = params ?: return
        val r = root ?: return
        val dm = context.resources.displayMetrics
        val center = lp.x + r.width / 2
        lp.x = if (center < dm.widthPixels / 2) 0 else (dm.widthPixels - r.width).coerceAtLeast(0)
        lp.y = lp.y.coerceIn(0, (dm.heightPixels - r.height).coerceAtLeast(0))
        try { wm.updateViewLayout(r, lp) } catch (e: Exception) { /* ignore */ }
    }

    // ---------- Hub events ----------

    override fun onTrackChanged() = syncTrack()
    override fun onPlayStateChanged() = syncPlayState()
    override fun onVoiceChanged() = syncVoice()
    override fun onRoutingChanged() = syncRouting()
    override fun onMessage(msg: String) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    }

    // ---------- Drag ----------

    private inner class DragListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        private var moved = false

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val lp = params ?: return false
            val r = root ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - touchX
                    val dy = event.rawY - touchY
                    if (!moved && (abs(dx) > dp(6) || abs(dy) > dp(6))) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        try { wm.updateViewLayout(r, lp) } catch (e: Exception) { /* ignore */ }
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        setExpanded(!expanded)
                    } else if (!expanded) {
                        snapToEdge()
                    } else {
                        clampToScreen()
                    }
                    return true
                }
            }
            return false
        }
    }
}
