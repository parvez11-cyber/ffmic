package com.ffmicplayer

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

/**
 * Ekta shared jaygay player + effects + routing state.
 * MainActivity ar floating overlay duitai ekhane theke control kore, tai
 * app minimize/close korleo (service cholle) floating icon theke sob kaj kore.
 *
 * Sob public function main thread theke call korte hobe.
 */
object PlayerHub {

    private const val TAG = "PlayerHub"

    interface Listener {
        fun onTrackChanged() {}
        fun onPlayStateChanged() {}
        fun onVoiceChanged() {}
        fun onRoutingChanged() {}
        fun onMessage(msg: String) {}
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val listeners = CopyOnWriteArrayList<Listener>()

    private var player: MusicPlayer? = null

    var equalizer: EqualizerManager? = null
        private set

    var songs: List<Song> = emptyList()
        private set
    var currentIndex: Int = -1
        private set
    private var currentPath: String? = null

    var voice: VoicePreset = VoicePreset.NORMAL
        private set
    var volume: Float = 0.8f
        private set

    var shuffle: Boolean = false
    var repeatMode: Int = 1          // 0 = off, 1 = all, 2 = one
    var speed: Float = 1.0f
        private set
    var loudnessMb: Int = 0
        private set
    var sleepEndAt: Long = 0L
        private set
    private val sleepRunnable = Runnable {
        sleepEndAt = 0L
        player?.pause()
        fire { onPlayStateChanged() }
        fire { onMessage("😴 Sleep timer: gaan bondho hoyeche") }
    }

    var routingOn: Boolean = false
        private set
    var routingSpeaker: Boolean = false   // root chhara Speaker Mode
        private set
    var routingBusy: Boolean = false
        private set
    var routingTarget: Boolean = false
        private set

    // ---- setup ----

    fun init(context: Context) {
        if (player != null) return
        val p = MusicPlayer(context.applicationContext)
        p.onCompletionListener = { onTrackCompleted() }
        p.onErrorListener = { err -> postMessage("Error: $err") }
        p.setVolume(volume, volume)
        player = p
    }

    fun addListener(l: Listener) {
        if (!listeners.contains(l)) listeners.add(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    private fun fire(block: Listener.() -> Unit) {
        for (l in listeners) l.block()
    }

    private fun postMessage(msg: String) {
        mainHandler.post { fire { onMessage(msg) } }
    }

    // ---- song list ----

    fun setSongs(list: List<Song>) {
        songs = list
        currentIndex = currentPath?.let { path -> list.indexOfFirst { it.path == path } } ?: -1
    }

    fun currentSong(): Song? = songs.getOrNull(currentIndex)

    // ---- playback ----

    fun play(index: Int) {
        val p = player ?: return
        val song = songs.getOrNull(index) ?: return
        currentIndex = index
        currentPath = song.path

        val ok = p.load(song.path)
        if (!ok) {
            // error message onErrorListener diyei chole geche
            fire { onTrackChanged() }
            fire { onPlayStateChanged() }
            return
        }
        p.setVolume(volume, volume)
        p.play()
        attachEffects(p)

        fire { onTrackChanged() }
        fire { onPlayStateChanged() }
    }

    private fun attachEffects(p: MusicPlayer) {
        equalizer?.release()
        equalizer = EqualizerManager(p.getAudioSessionId())
        applyVoiceToEffects()
        equalizer?.setLoudness(loudnessMb)
        p.setSpeed(speed)
        p.setPitch(voice.pitch)
    }

    private fun applyVoiceToEffects() {
        val eq = equalizer ?: return
        try {
            eq.applyPreset(voice.eq)
            eq.setReverb(voice.reverb)
        } catch (e: Exception) {
            Log.e(TAG, "Apply voice error: ${e.message}")
        }
    }

    fun togglePlayPause() {
        val p = player ?: return
        if (currentIndex < 0) {
            if (songs.isEmpty()) {
                fire { onMessage("Song list khali — age app e song add koro") }
            } else {
                play(0)
            }
            return
        }
        if (p.isPlaying()) p.pause() else p.play()
        fire { onPlayStateChanged() }
    }

    private fun randomOther(): Int {
        if (songs.size <= 1) return 0
        var i: Int
        do { i = (0 until songs.size).random() } while (i == currentIndex)
        return i
    }

    fun next() {
        if (songs.isEmpty()) return
        play(if (shuffle) randomOther() else (currentIndex + 1).mod(songs.size))
    }

    // Gaan shesh holey auto
    private fun onTrackCompleted() {
        if (songs.isEmpty()) return
        when {
            repeatMode == 2 -> play(currentIndex)
            shuffle -> play(randomOther())
            currentIndex >= songs.size - 1 && repeatMode == 0 -> fire { onPlayStateChanged() }
            else -> play((currentIndex + 1).mod(songs.size))
        }
    }

    fun setSpeed(v: Float) {
        speed = v.coerceIn(0.5f, 1.5f)
        player?.setSpeed(speed)
    }

    fun setLoudness(mb: Int) {
        loudnessMb = mb.coerceIn(0, 1000)
        equalizer?.setLoudness(loudnessMb)
    }

    // minutes = 0 mane bondho
    fun setSleepTimer(minutes: Int) {
        mainHandler.removeCallbacks(sleepRunnable)
        if (minutes <= 0) {
            sleepEndAt = 0L
            return
        }
        sleepEndAt = System.currentTimeMillis() + minutes * 60_000L
        mainHandler.postDelayed(sleepRunnable, minutes * 60_000L)
    }

    fun previous() {
        if (songs.isEmpty()) return
        val idx = if (currentIndex > 0) currentIndex - 1 else songs.size - 1
        play(idx)
    }

    fun isPlaying(): Boolean = player?.isPlaying() ?: false
    fun position(): Int = player?.getCurrentPosition() ?: 0
    fun duration(): Int = player?.getDuration() ?: 0
    fun seekTo(ms: Int) { player?.seekTo(ms) }

    fun setVolume(v: Float) {
        volume = v.coerceIn(0f, 1f)
        player?.setVolume(volume, volume)
    }

    // ---- voice changer ----

    fun setVoice(v: VoicePreset) {
        voice = v
        applyVoiceToEffects()
        player?.setPitch(v.pitch)
        fire { onVoiceChanged() }
    }

    // ---- virtual mic routing (root) ----

    fun setRouting(on: Boolean) {
        if (routingBusy) return
        routingBusy = true
        routingTarget = on
        fire { onRoutingChanged() }

        // root commands slow hote pare, tai background thread-e
        executor.execute {
            val svc = AudioRoutingService.instance
            val ok = try {
                if (on) {
                    svc?.startRouting() ?: false
                } else {
                    svc?.stopRouting()
                    true
                }
            } catch (e: Exception) {
                Log.e(TAG, "Routing error: ${e.message}")
                false
            }
            mainHandler.post {
                routingBusy = false
                routingOn = on && ok
                routingSpeaker = routingOn && (AudioRoutingService.instance?.speakerMode ?: false)
                if (on && !ok) {
                    fire { onMessage("Routing failed — Root Diagnose chalao") }
                } else if (routingSpeaker) {
                    fire { onMessage("Speaker Mode: headphone khulo, media volume barao") }
                }
                fire { onRoutingChanged() }
            }
        }
    }

    // ---- service quit ----

    fun shutdown() {
        player?.release()
        equalizer?.release()
        equalizer = null
        routingOn = false
        routingSpeaker = false
        routingBusy = false
        fire { onPlayStateChanged() }
        fire { onRoutingChanged() }
    }
}
